
//place dummy distance in and down in the meaty code repopulate with the splitlist distance value

//replace down in the meat the settings recal to the -animal -leia -gabrat settings

print("\\Clear");
print("* * * * * * * * * * * * * * * * * * * *");
print("Batch QCPA Workflow");
print("* * * * * * * * * * * * * * * * * * * *");




parentPath = getDirectory("Choose a Directory");
speciesList = getFileList(parentPath);
numSpecies = speciesList.length;
print("Working Directory Location: "+parentPath);
print("Number of species folders found = "+numSpecies);

fs = File.separator;
ext = ".ORF";		//Input File Extension
mspecname = ".mspec";
chrlim = "0.03"
lumlim = "0.00001"
roiManager("reset");
run("Clear Results");
ROIOptionsArray =newArray("Animal ROI","Animal + Background", "Background ROI");
ModulesArray = newArray("CAA,BSA,VCA & Particle Analysis", "LEIA", "GabRat", "RNL Colour Maps");
str = getDirectory("plugins")+"Cone Models";
coneList =getFileList(str);

//Macro Paths
batchToolsPath = getDirectory("plugins")+"micaToolbox"+fs+"Batch QCPA"+fs+"Tools"+fs;
frameworkTool = batchToolsPath+"Tool_Batch_Framework.ijm";
batchAcuityView = batchToolsPath+"Tool_Batch-Acuity_View.ijm";
batchAcuityGaussian = batchToolsPath+"Tool_Batch-Gaussian_Acuity_Control.ijm";
batchClusterAnalysis = batchToolsPath+"Tool_Batch-Cluster_Particle_Analysis.ijm";
batchNaiveBayes = batchToolsPath+"Tool_Batch-Naive_Bayes_Quantisation.ijm";
batchGabrat = batchToolsPath+"Tool_Batch-Gabrat_Disruption_ROIs.ijm";




settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch_MasterSettings.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	}

ext = defaultSettings[0];
mspecname = defaultSettings[1];
inputDist = defaultSettings[2];

inputWeberNum = defaultSettings[3];
inputRotationOption = defaultSettings[4];
chrlim = defaultSettings[5];
lumlim = defaultSettings[6];
inputROIChoices = defaultSettings[7];
	ROIChoicesArray = split(inputROIChoices, ",");
inputModuleOptions = defaultSettings[8];
	ModuleChoicesArray = split(inputModuleOptions,",");


//MAIN Input Parameters
Dialog.create("Main QCPA Input Parameters");
	Dialog.addString("Choose your file extension", ext);
	Dialog.addMessage("");
	Dialog.addString("Enter your mspec filename", mspecname);
	Dialog.addMessage("");
	Dialog.addString("Add viewing distances in same unit as the scale bar in each image", inputDist);
	Dialog.addMessage("If using more than one distance ensure values are separated by a comma");Dialog.addMessage("");
	Dialog.addMessage("");
	Dialog.addChoice("Number of spectral sensitivites (excl. luminance channel) required?", newArray("1","2","3","4"), inputWeberNum);
	Dialog.addCheckbox("Enable rotation?", inputRotationOption);
	Dialog.addMessage("");
	Dialog.addString("Choose your lower chromaticity limit", chrlim);
	Dialog.addString("Replace negative cone catch values with:", lumlim);
	Dialog.addMessage("Use 'IGNORE' above to ignore these settings and use a value of 0");
	Dialog.addMessage("");
	Dialog.addMessage("Select the ROIs you would like to measure below:");
	Dialog.addMessage("");
	for (i = 0; i < ROIOptionsArray.length; i++) {
		Dialog.addCheckbox(ROIOptionsArray[i], ROIChoicesArray[i]);
	}
	Dialog.addMessage("");
	Dialog.addMessage("Select the modules you would like to use below:");
	Dialog.addMessage("Note that Colour maps will not work with less than two colour channels (dichromacy)");
	Dialog.addMessage("");
	for (i = 0; i < ModulesArray.length; i++) {
		Dialog.addCheckbox(ModulesArray[i], ModuleChoicesArray[i]);
	}
	Dialog.show();

ext = Dialog.getString();
mspecname = Dialog.getString();
distList = Dialog.getString();
customWebFracNumber = Dialog.getChoice();
	customWebFracNumber =parseInt(customWebFracNumber);
rotationMode = Dialog.getCheckbox();
chrlim = Dialog.getString();
lumlim = Dialog.getString();
moduleAnimalROI = Dialog.getCheckbox();
moduleAnimalplusBackground = Dialog.getCheckbox();
moduleBackgroundROI = Dialog.getCheckbox();
moduleQCPA = Dialog.getCheckbox();
moduleLEIA = Dialog.getCheckbox();
moduleGABRAT = Dialog.getCheckbox();
moduleRNLColourMap = Dialog.getCheckbox();

// * * * Writing settings 1 - QCPA Batch-Masterdule.txt
settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch_MasterSettings.txt";
dataFile = File.open(settingsFilePath);
	print(dataFile, ext);
	print(dataFile, mspecname);
	print(dataFile, distList);
	print(dataFile, customWebFracNumber);
	print(dataFile, rotationMode);
	print(dataFile, chrlim);
	print(dataFile, lumlim);
	print(dataFile, moduleAnimalROI+","+moduleAnimalplusBackground+","+moduleBackgroundROI);
	print(dataFile, moduleQCPA+","+moduleLEIA+","+moduleGABRAT+","+moduleRNLColourMap);
File.close(dataFile);

print("File extension chosen: "+ext);
print("mspec file name chosen: "+mspecname);
print("Distances to calculate = "+distList);
splitList = split(distList,",");
print("Number of distances to calculate = "+splitList.length);
distance = splitList[0];
print("Number of spectral sensitivities: "+customWebFracNumber);
if(rotationMode==1){print("Rotation Mode is active");}
if(rotationMode==0){print("Rotation Mode is disabled");}
print("Lower chromacity limit: "+chrlim);
print("Replace negative cone catch values with: "+lumlim);
print("");
print("* * * * * * * * * * * * * * * * * * * * ");
print("Module selections: (0=off, 1 =on)");
print("AnimalROI: "+moduleAnimalROI);
print("Animal + Background: "+moduleAnimalplusBackground);
print("BackgroundROI: "+moduleBackgroundROI);
print("CAA, BSA, VCA & Particle Analysis: "+moduleQCPA);
print("LEIA: "+moduleLEIA);
print("GabRat: "+moduleGABRAT);
print("RNL Colour Maps: "+moduleRNLColourMap);
print("");



if(chrlim=="IGNORE"){chrlimIgnore = true;}
	else {chrlimIgnore = false;}
if(lumlim=="IGNORE"){lumlimIgnore = true;}
	else{lumlimIgnore = false;};

customWeberTitles = newArray("lw", "mw", "sw", "uv");


Dialog.create("Custom Weber Fractions Input");
	for (i = 0; i < customWebFracNumber; i++) {
		Dialog.addString("Weber Fraction Name & Number (names need to match toolbox files)", customWeberTitles[i]);Dialog.addToSameRow();Dialog.addString("", "0.05");}
		Dialog.addString("Weber Fraction for Luminance channel (always called lum irr. of toolbox files)", "lum");Dialog.addToSameRow();Dialog.addNumber("", "0.05");;
		Dialog.show();

weberFracNameArray = newArray(customWebFracNumber);
weberFracNumArray = newArray(customWebFracNumber);

for(h=0; h<(customWebFracNumber); h++){
	weberFracNameArray[h] = Dialog.getString();
	weberFracNumArray[h] = Dialog.getString();
	}
lumWeber = Dialog.getNumber();

weberFractionsFilePath = getDirectory("plugins")+"micaToolbox"+fs+"weberFractions"+fs;
weberFractionsFile = File.open(weberFractionsFilePath+"CustomWeberFraction.txt");
print(weberFractionsFile, "Custom Weber Fractions File produced by Batch QCPA Analysis Tool");
print("Custom Weber Fractions");

for(h=0; h<(customWebFracNumber); h++){
	print(weberFractionsFile, weberFracNameArray[h]+"\t"+weberFracNumArray[h]);
	print(weberFracNameArray[h]+"\t"+ " = " +weberFracNumArray[h]);
}
print("Luminance channel = "+lumWeber);
File.close(weberFractionsFile);




if (moduleQCPA==1){
	// * * * START QCPA subModule -  QCPA Framework Settings
	
	showMessage("Batch CAA, BSA, VCA and Particle Analysis - About", "<html>" 
    +"<H2><font size=4>The following menus and user input settings relate to the running of the CAA, BSA, VCA and Particle Analyses module within the QCPA framework</H2>"
    +"<br>"
    +"<p1><font size=3> We recommend Gaussian acuity correction, RNL filtering and RNL clustering to be applied for best outcomes when using CAA, BSA, VCA and Particle Analysis." 
    +"<br>"
    +"<P1><font size=3> "
    +"<br>" 
    +"<p1><font size=3> More information about QCPA can be found <a href=https://www.empiricalimaging.com/knowledge-base/running-the-qcpa-framework/>here</a></p1>" 
    +"<br>"
    +"<P1><font size=3> "
    +"<br>" 
    +"<P1><font size=3> Do not forget to cite the original publications:"
    +"<br>"
    +"<P1><font size=3> "
    +"<br>" 
    +"<P1><font size=3> QCPA framework: <a href=https://besjournals.onlinelibrary.wiley.com/doi/full/10.1111/2041-210X.13328>here</a></P1>"
    +"<br>"
    +"<P1><font size=3> MICA toolbox: <a href=https://besjournals.onlinelibrary.wiley.com/doi/pdf/10.1111/2041-210X.12439>here</a></P1>"
    +"<br>"
    +"<P1><font size=3> Colour Adjacency Analysis (CAA): <a href=https://academic.oup.com/biolinnean/article/107/2/233/2701487?login=false>here</a></P1>"
    +"<br>"
    +"<P1><font size=3> Boundary Strength Analysis (BSA): <a href=https://besjournals.onlinelibrary.wiley.com/doi/10.1111/2041-210X.13073>here</a></P1>"
    +"<br>"
    +"<P1><font size=3> Visual Contrast Analysis (VCA): <a href=https://academic.oup.com/biolinnean/article/86/4/405/2706048?login=false>here</a></P1>"
    +"<br>" 
    +"<P1><font size=3> "
    +"<br>" 
    +"<P1><font size=3> To cite ImageJ and the Particle Analysis tool: <a href=https://www.nature.com/articles/nmeth.2089>here</a></P1>"
    +"<br>"
    +"");
	
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPA.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	}
	
	acuityMethod = newArray("None", "Gaussian");
	//clusterMethod = newArray("None", "RNL Cluster", "Naive Bayes");
	clusterMethod = newArray("RNL Cluster", "None");
							
	Dialog.create("QCPA sub-Module - QCPA General Framework Options");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("General QCPA Settings for CAA, BSA, VCA and Particle Analyses");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("Select which aspects of processing to apply:");
		Dialog.addChoice("Acuity correction", acuityMethod, defaultSettings[0]);
		Dialog.addMessage("QCPA's implementation of AcuityView predates the R package and is an independent modification of code obtained from S. Johnsen, but is referred to as AcuityView to avoid confusion. It is fast and uses FFT, but requires use on whole-images rather than ROIs.\n \nThe Gaussian method is slightly slower, but can measure ROIs independently of their surroundings. Gaussian acuity correction is therefore the preferred choice in most cases.");
		Dialog.addCheckbox("RNL_Ranked_Filter", defaultSettings[1]);
		Dialog.addChoice("Clustering", clusterMethod, defaultSettings[2]);
		if (moduleLEIA==1){Dialog.addMessage("If using LEIA mode, its not recommended to run clustering.");}
		if (moduleGABRAT==1){Dialog.addMessage("Note: if using GabRat it is not recommended to run RNL filtering or RNL clustering.");}
		if(moduleRNLColourMap==1){Dialog.addMessage("RNL Filtering and clustering will affect the output of the Colour Maps. We recommend only applying RNL filtering in addition to acuity corrections, if at all. This will make the Colour Maps more concise as intermediate colours are reduced in range");}
		//Dialog.addNumber("Luminance Weber fraction", defaultSettings[4]); // this can come from the custom weber menu
		Dialog.addCheckbox("Particle Analysis", defaultSettings[5]);
		Dialog.addMessage("When using the QCPA framework cite: \n \nvan den Berg & Troscianko et al. (2020), Quantitative Colour Pattern Analysis (QCPA): A Comprehensive Framework for the Analysis of Colour Patterns in Nature, \nMethods in Ecology and Evolution, 11, 316-332");
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/running-the-qcpa-framework/");
	Dialog.show();

	acCorChoice = Dialog.getChoice();
	runWRF = Dialog.getCheckbox();
	clChoice = Dialog.getChoice();
	vsChoice = 		"CustomWeberFraction";
	//lumWeber = Dialog.getNumber();
	plAnalysis = Dialog.getCheckbox();

	// * * * Writing settings 1 - QCPA Batch-Frameworksettings_QCPA-subModule.txt
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPA.txt";
	dataFile = File.open(settingsFilePath);
		print(dataFile, acCorChoice);
		print(dataFile, runWRF);
		print(dataFile, clChoice);
		print(dataFile, vsChoice);
		print(dataFile, lumWeber);
		print(dataFile, plAnalysis);
		print(dataFile, "0");
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("QCPA Framework Options: ");
	print("Acuity Correction Method: "+acCorChoice);
	print("RNL Ranked Filter: "+runWRF);
	print("Clustering method: "+clChoice);
	print("Luminance Weber fraction: "+lumWeber);
	print("Particle Analysis: "+plAnalysis);
	print("");	
	
	// * * * START QCPA Sub-Module - Accuity Menu Options
	if (acCorChoice=="Gaussian" || acCorChoice=="AcuityView") {	
		settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPA.txt";
		if(File.exists(settingsFilePath) == 1){
			settingsString=File.openAsString(settingsFilePath);	// open txt data file
			defaultSettings=split(settingsString, "\n");
		}
																			
		//acChoice = newArray("Minimum resolvable angle", "Cycles per degree");
		acChoice = newArray("Cycles per degree");
		//calcChoice = newArray("Angular width of image", "Viewing distance");
		calcChoice = newArray("Viewing distance");
		
		Dialog.create("Acuity correction");
			Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
			Dialog.addMessage("QCPA acuity correction (CAA, BSA, VCA & Particle Analysis");
			Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
			Dialog.addMessage("_________________________________________Acuity Settings_________________________________________");
			Dialog.addChoice("Acuity units:", acChoice, defaultSettings[0]);
			Dialog.addNumber("Acuity value", defaultSettings[1]);
			Dialog.addMessage("____________________________________Distance/Angle Settings____________________________________");
			Dialog.addChoice("Method:", calcChoice, defaultSettings[2]);
			Dialog.addMessage("If using 'Viewing distance' the image must contain a scale-bar, and the units entered above\nmust match the scale bar units (e.g. mm). All angles are in degrees");
			Dialog.addNumber("Rescale to px per MRA", defaultSettings[4]);
			Dialog.addMessage("Automatically re-scale the image to a set number of pixels per MRA, 0=off. A value of 5 is recommended to avoid loosing more than 2% of spatial information");
			Dialog.addMessage("________________________________________Background Info________________________________________");
			Dialog.addMessage("AcuityView in QCPA is based on a 2016 Matlab script by S. Johnsen. Both, Gaussian & AcuityView remove spatial information that isn't available to a given visual system.\nHowever, a host of other/additional processing steps may go into truly approximating what an animal perceives.");
			
		Dialog.show();
	
		acUnits = Dialog.getChoice();
		acValue = Dialog.getNumber();
		acMethod = Dialog.getChoice();
		acDistance = distance;
		acRescale = Dialog.getNumber();		
						
		// * * * Writing settings 2 - QCPA Batch-AcuitySettings_subModule.txt
		settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPA.txt";
		dataFile = File.open(settingsFilePath);
			print(dataFile, acUnits);
			print(dataFile, acValue);
			print(dataFile, acMethod);
			print(dataFile, distance);
			print(dataFile, acRescale);
		File.close(dataFile);
		
		print("- - - - - - - - - - - - - - - - - - - - -");
		print("QCPA Sub-Module - Acuity View Options:");
		print("Acuity Units: "+acUnits);
		print("Acuity Value: "+acValue);
		print("Acuity Method: "+acMethod);
		print("Viewing Distances: "+distList);
		print("Rescale to MRA: "+acRescale);
		print("");
		// * * * END QCPA - Acuity Sub-module Settings
	}
	
	// * * * START  WRF / RNL Ranked Filter Settings
	if (runWRF ==1){
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPA.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	}

	Dialog.create("RNL Ranked Filter Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("RNL Ranked Filter Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addNumber("Iterations:", defaultSettings[0]);
		Dialog.addNumber("Radius:", defaultSettings[1]);
		Dialog.addMessage("If you specified a pixels-per-MRA, you should\nuse the same number as the radius here.");
		Dialog.addNumber("Falloff:", defaultSettings[2]);
		Dialog.addMessage("Higher falloff values create a steeper falloff\nin the influence of neighbouring pixels,\npreserving more fine detail");
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/rnl-ranked-filter/");	
	Dialog.show();
	
	iterations = parseInt(Dialog.getNumber());
	radius = parseInt(Dialog.getNumber());
	falloff = Dialog.getNumber();

	// * * *  Writing settings 3 - Batch_wrfSettings_SubModule.txt
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPA.txt";
	dataFile = File.open(settingsFilePath);
		//print(dataFile, lumWeber);
		print(dataFile, iterations);
		print(dataFile, radius);
		print(dataFile, falloff);
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("RNL Ranked Filter Options: ");
	print("Iterations: "+iterations);
	print("Radius: "+radius);
	print("Falloff: "+falloff);
	print("");
	}//end WRF loop

if (clChoice == "RNL Cluster"){
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLcluster-QCPA.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	} 

	Dialog.create("RNL Clustering Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("RNL Clustering Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addNumber("Colour JND Threshold", defaultSettings[0]);
		Dialog.addNumber("Luminance JND Threshold", defaultSettings[1]);
		Dialog.addNumber("Loops", defaultSettings[2]);
		Dialog.addNumber("Radius multiplier", defaultSettings[3]);
		Dialog.addNumber("Minimum cluster size", defaultSettings[4]);
		Dialog.addNumber("Compare all clusters from pass:", defaultSettings[5]);
		Dialog.addNumber("Stop clustering if number of clusters is below", defaultSettings[6]);
		Dialog.addNumber("Record output from pass", defaultSettings[7]);
		//Dialog.addString("Image Label", "filename", defaultSettings[8]);
		//Dialog.addNumber("Luminance Weber fraction", defaultSettings[9]);
		Dialog.addCheckbox("Show separate horizontal and vertical adjacency results", defaultSettings[10]); 
		Dialog.addCheckbox("Output adjacency matrix", defaultSettings[11]); 
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/rnl-clustering/");	
	Dialog.show();

	colJND = Dialog.getNumber();
	lumJND = Dialog.getNumber();
	loops = parseInt(Dialog.getNumber());
	rMultiplier = Dialog.getNumber();
	minSize = parseInt(Dialog.getNumber());
	compareFrom = parseInt(Dialog.getNumber());
	stopN = parseInt(Dialog.getNumber());
	recordFrom = parseInt(Dialog.getNumber());
	imLabel = "filename";
	hvOutput = Dialog.getCheckbox();
	mOutput = Dialog.getCheckbox();

	// -----------------------SAVE PREVIOUSLY USED SETTINGS----------------------------
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLcluster-QCPA.txt";
	dataFile = File.open(settingsFilePath);
		print(dataFile, colJND);
		print(dataFile, lumJND);
		print(dataFile, loops);
		print(dataFile, rMultiplier);
		print(dataFile, minSize);
		print(dataFile, compareFrom);
		print(dataFile, stopN);
		print(dataFile, recordFrom);
		print(dataFile, imLabel);
		print(dataFile, "X"); //printing 'junk' to ensure array stays same size
		print(dataFile, hvOutput);
		print(dataFile, mOutput);
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("RNL Clustering Options: ");
	print("ColourJND Threshold: "+colJND);
	print("Luminance JND Threshold: "+lumJND);
	print("Loops: "+loops);
	print("Radius Multiplier: "+rMultiplier);
	print("Minimum cluster size: "+minSize);
	print("Compare all clusters from pass: "+compareFrom);
	print("Stop clustering if number of clusters is below: "+stopN);
	print("Record output from pass: "+recordFrom);
	print("Show seperate horizontal + vertical adjacency results: "+hvOutput);
	print("Output adjacency matrix: "+mOutput);
	print("");
	
}//End RNL Clustering sub-Module
}
	// * * * END QCPA sub-Module - QCPA Framework settings

if (moduleLEIA==1){
	// * * * START LEIA Module -  QCPA Framework Settings
	
	showMessage("Batch QCPA With LEIA - About", "<html>" 
    +"<H2><font size=4>The following menus and user input settings relate to the running of the Local Edge Intensity (LEIA) module within the QCPA framework</H2>"
    +"<br>"
    +"<p1><font size=3> We recommend Gaussian acuity correction, RNL filtering but no RNL clustering to be applied for best outcomes when using LEIA." 
    +"<br>"
    +"<P1><font size=3> "
    +"<br>" 
    +"<p1><font size=3> More information about QCPA can be found <a href=https://www.empiricalimaging.com/knowledge-base/running-the-qcpa-framework/>here</a></p1>" 
    +"<br>"
    +"<P1><font size=3> "
    +"<br>" 
    +"<P1><font size=3> Do not forget to cite the original publications:"
    +"<br>"
    +"<P1><font size=3> "
    +"<br>" 
    +"<P1><font size=3> QCPA framework & LEIA: <a href=https://besjournals.onlinelibrary.wiley.com/doi/full/10.1111/2041-210X.13328>here</a></P1>"
    +"<br>"
    +"<P1><font size=3> MICA toolbox: <a href=https://besjournals.onlinelibrary.wiley.com/doi/pdf/10.1111/2041-210X.12439>here</a></P1>"
    +"<P1><font size=3> "
    +"<br>"
    +"<P1><font size=3> "
    +"<P1><font size=3> To cite ImageJ: <a href=https://www.nature.com/articles/nmeth.2089>here</a></P1>"
    +"<br>"
    +"");
	
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPALEIA.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	}
	
	acuityMethod = newArray("None", "Gaussian");
	//clusterMethod = newArray("None", "RNL Cluster", "Naive Bayes");
	clusterMethod = newArray("RNL Cluster", "None");
							
	Dialog.create("LEIA sub-Module - General QCPA Framework Options");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("General QCPA Settings for LEIA");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("Select which aspects of processing to apply:");
		Dialog.addChoice("Acuity correction", acuityMethod, defaultSettings[0]);
		Dialog.addMessage("QCPA's implementation of AcuityView predates the R package and is an independent modification of code obtained from S. Johnsen, but is referred to as AcuityView to avoid confusion. It is fast and uses FFT, but requires use on whole-images rather than ROIs.\n \nThe Gaussian method is slightly slower, but can measure ROIs independently of their surroundings. Gaussian acuity correction is therefore the preferred choice in most cases.");
		Dialog.addCheckbox("RNL_Ranked_Filter", defaultSettings[1]);
		Dialog.addChoice("Clustering", clusterMethod, defaultSettings[2]);
		if (moduleLEIA==1){Dialog.addMessage("If using LEIA mode, its not recommended to run clustering. However, RNL filtering is recommended to compensate for acuity processing.");}
		if (moduleGABRAT==1){Dialog.addMessage("Note: if using GabRat it is not recommended to run RNL filtering or RNL clustering.");}
		if(moduleRNLColourMap==1){Dialog.addMessage("RNL Filtering and clustering will affect the output of the Colour Maps. We recommend only applying RNL filtering in addition to acuity corrections, if at all. This will make the Colour Maps more concise as intermediate colours are reduced in range");}
		//Dialog.addNumber("Luminance Weber fraction", defaultSettings[4]); // this can come from the custom weber menu
		Dialog.addCheckbox("Particle Analysis", defaultSettings[5]);
		Dialog.addMessage("When using the QCPA framework cite: \n \nvan den Berg & Troscianko et al. (2020), Quantitative Colour Pattern Analysis (QCPA): A Comprehensive Framework for the Analysis of Colour Patterns in Nature, \nMethods in Ecology and Evolution, 11, 316-332");
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/running-the-qcpa-framework/");
	Dialog.show();
	

	acCorChoice = Dialog.getChoice();
	runWRF = Dialog.getCheckbox();
	clChoice = Dialog.getChoice();
	vsChoice = 		"CustomWeberFraction";
	//lumWeber = Dialog.getNumber();
	plAnalysis = Dialog.getCheckbox();

	// * * * Writing settings 1 - QCPA Batch-Frameworksettings_QCPA-subModule.txt
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPALEIA.txt";
	dataFile = File.open(settingsFilePath);
		print(dataFile, acCorChoice);
		print(dataFile, runWRF);
		print(dataFile, clChoice);
		print(dataFile, vsChoice);
		print(dataFile, lumWeber);
		print(dataFile, plAnalysis);
		print(dataFile, "0");
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("QCPA Framework Options: ");
	print("Acuity Correction Method: "+acCorChoice);
	print("RNL Ranked Filter: "+runWRF);
	print("Clustering method: "+clChoice);
	print("Luminance Weber fraction: "+lumWeber);
	print("Particle Analysis: "+plAnalysis);
	print("");	
	
	// * * * START QCPA Sub-Module - Accuity Menu Options
	if (acCorChoice=="Gaussian" || acCorChoice=="AcuityView") {	
		settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPALEIA.txt";
		if(File.exists(settingsFilePath) == 1){
			settingsString=File.openAsString(settingsFilePath);	// open txt data file
			defaultSettings=split(settingsString, "\n");
		}
																			
		//acChoice = newArray("Minimum resolvable angle", "Cycles per degree");
		acChoice = newArray("Cycles per degree");
		//calcChoice = newArray("Angular width of image", "Viewing distance");
		calcChoice = newArray("Viewing distance");
		
		
		
		Dialog.create("Acuity correction");
			Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
			Dialog.addMessage("QCPA acuity correction (LEIA)");
			Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
			Dialog.addMessage("_________________________________________Acuity Settings_________________________________________");
			Dialog.addChoice("Acuity units:", acChoice, defaultSettings[0]);
			Dialog.addNumber("Acuity value", defaultSettings[1]);
			Dialog.addMessage("____________________________________Distance/Angle Settings____________________________________");
			Dialog.addChoice("Method:", calcChoice, defaultSettings[2]);
			Dialog.addMessage("If using 'Viewing distance' the image must contain a scale-bar, and the units entered above\nmust match the scale bar units (e.g. mm). All angles are in degrees");
			Dialog.addNumber("Rescale to px per MRA", defaultSettings[4]);
			Dialog.addMessage("Automatically re-scale the image to a set number of pixels per MRA, 0=off. A value of 5 is recommended to avoid loosing more than 2% of spatial information");
			Dialog.addMessage("________________________________________Background Info________________________________________");
			Dialog.addMessage("AcuityView in QCPA is based on a 2016 Matlab script by S. Johnsen. Both, Gaussian & AcuityView remove spatial information that isn't available to a given visual system.\nHowever, a host of other/additional processing steps may go into truly approximating what an animal perceives.");
			
		Dialog.show();
	
	
		acUnits = Dialog.getChoice();
		acValue = Dialog.getNumber();
		acMethod = Dialog.getChoice();
		acDistance = distance;
		acRescale = Dialog.getNumber();		
						
		// * * * Writing settings 2 - QCPA Batch-AcuitySettings_subModule.txt
		settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPALEIA.txt";
		dataFile = File.open(settingsFilePath);
			print(dataFile, acUnits);
			print(dataFile, acValue);
			print(dataFile, acMethod);
			print(dataFile, distance);
			print(dataFile, acRescale);
		File.close(dataFile);
		
		print("- - - - - - - - - - - - - - - - - - - - -");
		print("QCPA Sub-Module - Acuity View Options:");
		print("Acuity Units: "+acUnits);
		print("Acuity Value: "+acValue);
		print("Acuity Method: "+acMethod);
		print("Viewing Distances: "+distList);
		print("Rescale to MRA: "+acRescale);
		print("");
		// * * * END QCPA - Acuity Sub-module Settings
	}
	
	// * * * START  WRF / RNL Ranked Filter Settings
	if (runWRF ==1){
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPALEIA.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	}

	Dialog.create("RNL Ranked Filter Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("RNL Ranked Filter Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addNumber("Iterations:", defaultSettings[0]);
		Dialog.addNumber("Radius:", defaultSettings[1]);
		Dialog.addMessage("If you specified a pixels-per-MRA, you should\nuse the same number as the radius here.");
		Dialog.addNumber("Falloff:", defaultSettings[2]);
		Dialog.addMessage("Higher falloff values create a steeper falloff\nin the influence of neighbouring pixels,\npreserving more fine detail");
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/rnl-ranked-filter/");	
	Dialog.show();
	
	iterations = parseInt(Dialog.getNumber());
	radius = parseInt(Dialog.getNumber());
	falloff = Dialog.getNumber();

	// * * *  Writing settings 3 - Batch_wrfSettings_SubModule.txt
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPALEIA.txt";
	dataFile = File.open(settingsFilePath);
		//print(dataFile, lumWeber);
		print(dataFile, iterations);
		print(dataFile, radius);
		print(dataFile, falloff);
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("RNL Ranked Filter Options: ");
	print("Iterations: "+iterations);
	print("Radius: "+radius);
	print("Falloff: "+falloff);
	print("");
	}//end WRF loop

if (clChoice == "RNL Cluster"){
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLcluster-LEIA.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	} 

	Dialog.create("RNL Clustering Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("RNL Clustering Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addNumber("Colour JND Threshold", defaultSettings[0]);
		Dialog.addNumber("Luminance JND Threshold", defaultSettings[1]);
		Dialog.addNumber("Loops", defaultSettings[2]);
		Dialog.addNumber("Radius multiplier", defaultSettings[3]);
		Dialog.addNumber("Minimum cluster size", defaultSettings[4]);
		Dialog.addNumber("Compare all clusters from pass:", defaultSettings[5]);
		Dialog.addNumber("Stop clustering if number of clusters is below", defaultSettings[6]);
		Dialog.addNumber("Record output from pass", defaultSettings[7]);
		//Dialog.addString("Image Label", "filename", defaultSettings[8]);
		//Dialog.addNumber("Luminance Weber fraction", defaultSettings[9]);
		Dialog.addCheckbox("Show separate horizontal and vertical adjacency results", defaultSettings[10]); 
		Dialog.addCheckbox("Output adjacency matrix", defaultSettings[11]); 
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/rnl-clustering/");	
	Dialog.show();

	colJND = Dialog.getNumber();
	lumJND = Dialog.getNumber();
	loops = parseInt(Dialog.getNumber());
	rMultiplier = Dialog.getNumber();
	minSize = parseInt(Dialog.getNumber());
	compareFrom = parseInt(Dialog.getNumber());
	stopN = parseInt(Dialog.getNumber());
	recordFrom = parseInt(Dialog.getNumber());
	imLabel = "filename";
	hvOutput = Dialog.getCheckbox();
	mOutput = Dialog.getCheckbox();

	// -----------------------SAVE PREVIOUSLY USED SETTINGS----------------------------
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLcluster-LEIA.txt";
	dataFile = File.open(settingsFilePath);
		print(dataFile, colJND);
		print(dataFile, lumJND);
		print(dataFile, loops);
		print(dataFile, rMultiplier);
		print(dataFile, minSize);
		print(dataFile, compareFrom);
		print(dataFile, stopN);
		print(dataFile, recordFrom);
		print(dataFile, imLabel);
		print(dataFile, "X"); //printing 'junk' to ensure array stays same size
		print(dataFile, hvOutput);
		print(dataFile, mOutput);
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("RNL Clustering Options: ");
	print("ColourJND Threshold: "+colJND);
	print("Luminance JND Threshold: "+lumJND);
	print("Loops: "+loops);
	print("Radius Multiplier: "+rMultiplier);
	print("Minimum cluster size: "+minSize);
	print("Compare all clusters from pass: "+compareFrom);
	print("Stop clustering if number of clusters is below: "+stopN);
	print("Record output from pass: "+recordFrom);
	print("Show seperate horizontal + vertical adjacency results: "+hvOutput);
	print("Output adjacency matrix: "+mOutput);
	print("");
	
}//End RNL Clustering sub-Module


	//Start LEIA LEIA Settings
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-leiaSettings.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	} 
	
	tOptions = newArray("none", "log", "sqrt");
	Dialog.create("Local Edge Intensity Analysis Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("LEIA Local Edge Intensity Analysis Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addChoice("Transform delta S values:", tOptions, defaultSettings[2]);
		Dialog.addNumber("Ignore_chromatic delta S values below:", defaultSettings[3]);
		Dialog.addNumber("Ignore_luminance delta S values below:", defaultSettings[4]);
		Dialog.addCheckbox("Show horizontal and vertical data", defaultSettings[5]);
		Dialog.addNumber("Maximum display value", defaultSettings[6]);
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/local-edge-intensity-analysis-leia/");
	Dialog.show();

	imLabel = "filename";
	//lumWeber = "1";
	tChoice = Dialog.getChoice();
	ict = Dialog.getNumber();
	ilt = Dialog.getNumber();
	hvOutputLEIA = Dialog.getCheckbox();
	maxDisplay = Dialog.getNumber();

	// -----------------------SAVE PREVIOUSLY USED SETTINGS----------------------------
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-leiaSettings-LEIA.txt";
	dataFile = File.open(settingsFilePath);
		print(dataFile, imLabel);
		print(dataFile, lumWeber);
		print(dataFile, tChoice);
		print(dataFile, ict);
		print(dataFile, ilt);
		print(dataFile, hvOutputLEIA);
		print(dataFile, maxDisplay);
	File.close(dataFile);		

	print("- - - - - - - - - - - - - - - - - - - - -");
	print("LEIA Options: ");
	print("Transform delta S values: "+tChoice);
	print("Ignore chromatic delta S values below:"+ict);
	print("Ignore luminance delta S values below: "+ilt);
	print("Show seperate horizontal + vertical adjacency results: "+hvOutputLEIA);
	print("Maximum display value: "+maxDisplay);
	print("");
}

	// * * * END LEIA sub-Module - QCPA LEIA Framework settings


if (moduleGABRAT==1){
	// * * * START Gabrat Module -  QCPA Framework Settings
	
	showMessage("Batch QCPA With GabRat - About", "<html>" 
    +"<H2><font size=4>The following menus and user input settings relate to the running of the Gabor Ratio (GabRat) module within the QCPA framework</H2>"
    +"<br>"
    +"<p1><font size=3> We recommend Gaussian acuity correction, but no RNL filtering and no RNL clustering to be applied for best outcomes when using GabRat." 
    +"<br>"
    +"<P1><font size=3> "
    +"<br>" 
    +"<p1><font size=3> More information about QCPA can be found <a href=https://www.empiricalimaging.com/knowledge-base/running-the-qcpa-framework/>here</a></p1>" 
    +"<br>"
    +"<P1><font size=3> "
    +"<br>" 
    +"<P1><font size=3> Do not forget to cite the original publications:"
    +"<br>"
    +"<P1><font size=3> "
    +"<br>" 
    +"<P1><font size=3> QCPA framework: <a href=https://besjournals.onlinelibrary.wiley.com/doi/full/10.1111/2041-210X.13328>here</a></P1>"
    +"<br>"
    +"<P1><font size=3> MICA toolbox: <a href=https://besjournals.onlinelibrary.wiley.com/doi/pdf/10.1111/2041-210X.12439>here</a></P1>"
    +"<P1><font size=3> "
    +"<br>"
    +"<P1><font size=3> GabRat: <a href=https://bmcecolevol.biomedcentral.com/articles/10.1186/s12862-016-0854-2>here</a></P1>"
    +"<br>"
    +"<P1><font size=3> "
    +"<P1><font size=3> To cite ImageJ: <a href=https://www.nature.com/articles/nmeth.2089>here</a></P1>"
    +"<br>"
    +"");
	
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPAGabRat.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	}
	
	acuityMethod = newArray("None", "Gaussian");
	//clusterMethod = newArray("None", "RNL Cluster", "Naive Bayes");
	clusterMethod = newArray("RNL Cluster", "None");
	
	
	Dialog.create("GabRat sub-Module - General QCPA Framework Options");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("General QCPA Settings for GabRat");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("Select which aspects of processing to apply:");
		Dialog.addChoice("Acuity Correction", acuityMethod, defaultSettings[0]);
		Dialog.addMessage("QCPA's implementation of AcuityView predates the R package and is an independent modification of code obtained from S. Johnsen, but is referred to as AcuityView to avoid confusion. It is fast and uses FFT, but requires use on whole-images.\n\nThe Gaussian method is slower, but can measure ROIs independently of their surroundings");
		Dialog.addCheckbox("RNL_Ranked_Filter", defaultSettings[1]);
		Dialog.addChoice("Clustering", clusterMethod, defaultSettings[2]);
		if (moduleLEIA==1){Dialog.addMessage("If using LEIA mode, its not recommended to run clustering. However, RNL filtering is recommended to compensate for acuity processing.");}
		if (moduleGABRAT==1){Dialog.addMessage("Note: if using GabRat it is not recommended to run RNL filtering or RNL clustering.");}
		if(moduleRNLColourMap==1){Dialog.addMessage("RNL Filtering and clustering will affect the output of the Colour Maps. We recommend only applying RNL filtering in addition to acuity corrections, if at all. This will make the Colour Maps more concise as intermediate colours are reduced in range");}
		//Dialog.addNumber("Luminance Weber fraction", defaultSettings[4]); // this can come from the custom weber menu
		Dialog.addCheckbox("Particle Analysis", defaultSettings[5]);
		Dialog.addMessage("When using the QCPA framework cite: \n \nvan den Berg & Troscianko et al. (2020), Quantitative Colour Pattern Analysis (QCPA): A Comprehensive Framework for the Analysis of Colour Patterns in Nature, \nMethods in Ecology and Evolution, 11, 316-332");
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/running-the-qcpa-framework/");
	Dialog.show();


	acCorChoice = Dialog.getChoice();
	runWRF = Dialog.getCheckbox();
	clChoice = Dialog.getChoice();
	vsChoice = 		"CustomWeberFraction";
	//lumWeber = Dialog.getNumber();
	plAnalysis = 0;

	// * * * Writing settings 1 - QCPA Batch-Frameworksettings_QCPA-subModule.txt
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPAGabRat.txt";
	dataFile = File.open(settingsFilePath);
		print(dataFile, acCorChoice);
		print(dataFile, runWRF);
		print(dataFile, clChoice);
		print(dataFile, vsChoice);
		print(dataFile, lumWeber);
		print(dataFile, plAnalysis);
		print(dataFile, "0"); //hard coded LEIA off
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("QCPA Framework Options: ");
	print("Acuity Correction Method: "+acCorChoice);
	print("RNL Ranked Filter: "+runWRF);
	print("Clustering method: "+clChoice);
	print("Luminance Weber fraction: "+lumWeber);
	print("Particle Analysis: "+plAnalysis);
	print("");	
	
	// * * * START QCPA Sub-Module - Accuity Menu Options
	if (acCorChoice=="Gaussian" || acCorChoice=="AcuityView") {	
		settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPAGabrat.txt";
		if(File.exists(settingsFilePath) == 1){
			settingsString=File.openAsString(settingsFilePath);	// open txt data file
			defaultSettings=split(settingsString, "\n");
		}
																			
		//acChoice = newArray("Minimum resolvable angle", "Cycles per degree");
		acChoice = newArray("Cycles per degree");
		//calcChoice = newArray("Angular width of image", "Viewing distance");
		calcChoice = newArray("Viewing distance");

		Dialog.create("Acuity correction");
			Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
			Dialog.addMessage("QCPA acuity correction (GabRat)");
			Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
			Dialog.addMessage("_________________________________________Acuity Settings_________________________________________");
			Dialog.addChoice("Acuity units:", acChoice, defaultSettings[0]);
			Dialog.addNumber("Acuity value", defaultSettings[1]);
			Dialog.addMessage("Note: Unlike other QCPA modules, GabRat should be used with the Lambda max. value obtained from a contrast sensitificty function (CSF) curve")
			Dialog.addMessage("____________________________________Distance/Angle Settings____________________________________");
			Dialog.addChoice("Method:", calcChoice, defaultSettings[2]);
			Dialog.addMessage("If using 'Viewing distance' the image must contain a scale-bar, and the units entered above\nmust match the scale bar units (e.g. mm). All angles are in degrees");
			Dialog.addNumber("Rescale to px per MRA", defaultSettings[4]);
			Dialog.addMessage("Automatically re-scale the image to a set number of pixels per MRA, 0=off. A value of 5 is recommended to avoid loosing more than 2% of spatial information");
			Dialog.addMessage("________________________________________Background Info________________________________________");
			Dialog.addMessage("AcuityView in QCPA is based on a 2016 Matlab script by S. Johnsen. Both, Gaussian & AcuityView remove spatial information that isn't available to a given visual system.\nHowever, a host of other/additional processing steps may go into truly approximating what an animal perceives.");
			
		Dialog.show();
				
	
		acUnits = Dialog.getChoice();
		acValue = Dialog.getNumber();
		acMethod = Dialog.getChoice();
		acDistance = distance;
		acRescale = Dialog.getNumber();		
						
		// * * * Writing settings 2 - QCPA Batch-AcuitySettings_subModule.txt
		settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPAGabrat.txt";
		dataFile = File.open(settingsFilePath);
			print(dataFile, acUnits);
			print(dataFile, acValue);
			print(dataFile, acMethod);
			print(dataFile, distance);
			print(dataFile, acRescale);
		File.close(dataFile);
		
		print("- - - - - - - - - - - - - - - - - - - - -");
		print("GabRat Sub-Module - Acuity correction Options:");
		print("Acuity Units: "+acUnits);
		print("Acuity Value: "+acValue);
		print("Acuity Method: "+acMethod);
		print("Viewing Distances: "+distList);
		print("Rescale to MRA: "+acRescale);
		print("");
		// * * * END QCPA - Acuity Sub-module Settings
	}
	
	// * * * START  WRF / RNL Ranked Filter Settings
	if (runWRF ==1){
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPAGabrat.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	}

	Dialog.create("RNL Ranked Filter Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("RNL Ranked Filter Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addNumber("Iterations:", defaultSettings[0]);
		Dialog.addNumber("Radius:", defaultSettings[1]);
		Dialog.addMessage("If you specified a pixels-per-MRA, you should\nuse the same number as the radius here.");
		Dialog.addNumber("Falloff:", defaultSettings[2]);
		Dialog.addMessage("Higher falloff values create a steeper falloff\nin the influence of neighbouring pixels,\npreserving more fine detail");
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/rnl-ranked-filter/");	
	Dialog.show();
	
	iterations = parseInt(Dialog.getNumber());
	radius = parseInt(Dialog.getNumber());
	falloff = Dialog.getNumber();

	// * * *  Writing settings 3 - Batch_wrfSettings_SubModule.txt
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPAGabrat.txt";
	dataFile = File.open(settingsFilePath);
		//print(dataFile, lumWeber);
		print(dataFile, iterations);
		print(dataFile, radius);
		print(dataFile, falloff);
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("RNL Ranked Filter Options: ");
	print("Iterations: "+iterations);
	print("Radius: "+radius);
	print("Falloff: "+falloff);
	print("");
	}//end WRF loop
if (clChoice == "RNL Cluster"){
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLcluster-Gabrat.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	} 

	Dialog.create("RNL Clustering Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("RNL Clustering Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addNumber("Colour JND Threshold", defaultSettings[0]);
		Dialog.addNumber("Luminance JND Threshold", defaultSettings[1]);
		Dialog.addNumber("Loops", defaultSettings[2]);
		Dialog.addNumber("Radius multiplier", defaultSettings[3]);
		Dialog.addNumber("Minimum cluster size", defaultSettings[4]);
		Dialog.addNumber("Compare all clusters from pass:", defaultSettings[5]);
		Dialog.addNumber("Stop clustering if number of clusters is below", defaultSettings[6]);
		Dialog.addNumber("Record output from pass", defaultSettings[7]);
		//Dialog.addString("Image Label", "filename", defaultSettings[8]);
		//Dialog.addNumber("Luminance Weber fraction", defaultSettings[9]);
		Dialog.addCheckbox("Show separate horizontal and vertical adjacency results", defaultSettings[10]); 
		Dialog.addCheckbox("Output adjacency matrix", defaultSettings[11]); 
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/rnl-clustering/");	
	Dialog.show();

	colJND = Dialog.getNumber();
	lumJND = Dialog.getNumber();
	loops = parseInt(Dialog.getNumber());
	rMultiplier = Dialog.getNumber();
	minSize = parseInt(Dialog.getNumber());
	compareFrom = parseInt(Dialog.getNumber());
	stopN = parseInt(Dialog.getNumber());
	recordFrom = parseInt(Dialog.getNumber());
	imLabel = "filename";
	hvOutput = Dialog.getCheckbox();
	mOutput = Dialog.getCheckbox();

	// -----------------------SAVE PREVIOUSLY USED SETTINGS----------------------------
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLcluster-Gabrat.txt";
	dataFile = File.open(settingsFilePath);
		print(dataFile, colJND);
		print(dataFile, lumJND);
		print(dataFile, loops);
		print(dataFile, rMultiplier);
		print(dataFile, minSize);
		print(dataFile, compareFrom);
		print(dataFile, stopN);
		print(dataFile, recordFrom);
		print(dataFile, imLabel);
		print(dataFile, "X"); //printing 'junk' to ensure array stays same size
		print(dataFile, hvOutput);
		print(dataFile, mOutput);
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("RNL Clustering Options: ");
	print("ColourJND Threshold: "+colJND);
	print("Luminance JND Threshold: "+lumJND);
	print("Loops: "+loops);
	print("Radius Multiplier: "+rMultiplier);
	print("Minimum cluster size: "+minSize);
	print("Compare all clusters from pass: "+compareFrom);
	print("Stop clustering if number of clusters is below: "+stopN);
	print("Record output from pass: "+recordFrom);
	print("Show seperate horizontal + vertical adjacency results: "+hvOutput);
	print("Output adjacency matrix: "+mOutput);
	print("");
	
}//End RNL Clustering sub-Module

//Start GABRAT Settings Modules


	//Start GABRAT QCPA 				
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-GABRAT_ROI-disruption.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
		}
	Dialog.create("Measure GabRat Edge Disruption");
		Dialog.addMessage("This applies the 'GabRat' measurement of edge\ndisruption. The edge disruption is measured for\neach ROI specified in the image and each channel");
		Dialog.addMessage("Please cite: Troscianko, J., Skelhorn, J. & Stevens,\nM. Quantifying camouflage: how to predict\ndetectability from appearance. BMC Evolutionary\nBiology 17, 7 (2017)");
		Dialog.addNumber("Number of angles", defaultSettings[0]);
		Dialog.addNumber("Sigma", defaultSettings[1]);
		Dialog.addNumber("Gamma aspect ratio", defaultSettings[2]);
		Dialog.addNumber("Frequency", defaultSettings[3]);
		Dialog.addMessage("Sigma is the most important variable to change\nas this controlls the scale of the kernel. Use the\n'GabRat Disruption' tool for assessing kernels\nand additional output information");
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/gabrat/");
	Dialog.show();
	
	gabRatAngle = Dialog.getNumber();
	gabRatSigma = Dialog.getNumber();
	gabRatGamma = Dialog.getNumber();
	gabRatFreq = Dialog.getNumber();
	

			
	// * * * Writing settings 1 - Batch-Frameworksettings-GABRAT.txt
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-GABRAT_ROI-disruption_GabRat_subModule.txt";
	dataFile = File.open(settingsFilePath);
		print(dataFile, gabRatAngle);
		print(dataFile, gabRatSigma);
		print(dataFile, gabRatGamma);
		print(dataFile, gabRatFreq);
	File.close(dataFile);
		
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("GabRat Options: ");
	print("Number of angles: "+gabRatAngle);
	print("Sigma: "+gabRatSigma);
	print("Gamma aspect ratio: "+gabRatGamma);
	print("Frequency: "+gabRatFreq);
	print("");
	

		
	} //End GabRat



	


	// * * * END QCPA sub-Module - QCPA GabRat Framework settings


if (moduleRNLColourMap==1){
	
	showMessage("Batch QCPA With Colour Maps - About", "<html>" 
    +"<H2><font size=4>The following menus and user input settings relate to the running of the Colour Maps module within the QCPA framework</H2>"
    +"<br>"
    +"<p1><font size=3> We recommend Gaussian acuity correction and RNL filtering to be used for Colour Maps. Clustered images can be used for Colour Maps but will naturally have a much more compressed distribution as colours are uniform within patches." 
    +"<br>"
    +"<P1><font size=3> "
    +"<br>" 
    +"<p1><font size=3> More information about QCPA can be found <a href=https://www.empiricalimaging.com/knowledge-base/running-the-qcpa-framework/>here</a></p1>" 
    +"<br>"
    +"<P1><font size=3> "
    +"<br>" 
    +"<P1><font size=3> Do not forget to cite the original publications:"
    +"<br>"
    +"<P1><font size=3> "
    +"<br>" 
    +"<P1><font size=3> QCPA framework & Colour Maps: <a href=https://besjournals.onlinelibrary.wiley.com/doi/full/10.1111/2041-210X.13328>here</a></P1>"
    +"<br>"
    +"<P1><font size=3> MICA toolbox: <a href=https://besjournals.onlinelibrary.wiley.com/doi/pdf/10.1111/2041-210X.12439>here</a></P1>"
    +"<P1><font size=3> "
    +"<br>"
    +"<P1><font size=3> "
    +"<P1><font size=3> To cite ImageJ: <a href=https://www.nature.com/articles/nmeth.2089>here</a></P1>"
    +"<br>"
    +"");


	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPARNL.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	}
	
	acuityMethod = newArray("None", "Gaussian");
	//clusterMethod = newArray("None", "RNL Cluster", "Naive Bayes");
	clusterMethod = newArray("RNL Cluster", "None");
	
	
	
	Dialog.create("Colour Maps sub-Module - General QCPA Framework Options");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("General QCPA Settings for Colour Maps");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("Select which aspects of processing to apply:");
		Dialog.addChoice("Acuity Correction", acuityMethod, defaultSettings[0]);
		Dialog.addMessage("QCPA's implementation of AcuityView predates the R package and is an independent modification of code obtained from S. Johnsen, but is referred to as AcuityView to avoid confusion. It is fast and uses FFT, but requires use on whole-images.\nThe Gaussian method is slower, but can measure ROIs independently\nof their surroundings");
		Dialog.addCheckbox("RNL_Ranked_Filter", defaultSettings[1]);
		Dialog.addChoice("Clustering", clusterMethod, defaultSettings[2]);
		if (moduleLEIA==1){Dialog.addMessage("If using LEIA mode, its not recommended to run clustering. However, RNL filtering is recommended to compensate for acuity processing.");}
		if (moduleGABRAT==1){Dialog.addMessage("Note: if using GabRat it is not recommended to run RNL filtering or RNL clustering.");}
		if(moduleRNLColourMap==1){Dialog.addMessage("RNL Filtering and clustering will affect the output of the Colour Maps. We recommend only applying RNL filtering in addition to acuity corrections, if at all. This will make the Colour Maps more concise as intermediate colours are reduced in range");}
		//Dialog.addNumber("Luminance Weber fraction", defaultSettings[4]); // this can come from the custom weber menu
		Dialog.addCheckbox("Particle Analysis", defaultSettings[5]);
		Dialog.addMessage("When using the QCPA framework cite: \n \nvan den Berg & Troscianko et al. (2020), Quantitative Colour Pattern Analysis (QCPA): A Comprehensive Framework for the Analysis of Colour Patterns in Nature, \nMethods in Ecology and Evolution, 11, 316-332");
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/running-the-qcpa-framework/");
	Dialog.show();
							

	acCorChoice = Dialog.getChoice();
	runWRF = Dialog.getCheckbox();
	clChoice = Dialog.getChoice();
	vsChoice = 		"CustomWeberFraction";
	//lumWeber = Dialog.getNumber();
	plAnalysis = Dialog.getCheckbox();

	// * * * Writing settings 1 - QCPA Batch-Frameworksettings_QCPA-subModule.txt
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPARNL.txt";
	dataFile = File.open(settingsFilePath);
		print(dataFile, acCorChoice);
		print(dataFile, runWRF);
		print(dataFile, clChoice);
		print(dataFile, vsChoice);
		print(dataFile, lumWeber);
		print(dataFile, plAnalysis);
		print(dataFile, "0");
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("QCPA Framework Options: ");
	print("Acuity Correction Method: "+acCorChoice);
	print("RNL Ranked Filter: "+runWRF);
	print("Clustering method: "+clChoice);
	print("Luminance Weber fraction: "+lumWeber);
	print("Particle Analysis: "+plAnalysis);
	print("");	
	
	// * * * START QCPA Sub-Module - WRF (RNL Ranked Filter) Settings for Colour Maps
    if (runWRF == 1) {

        weberSettingsPath = getDirectory("plugins") +
            "micaToolbox/Batch QCPA/Settings/Batch-wrfSettings.txt";

        // Load existing defaults, if any
        if (File.exists(weberSettingsPath) == 1) {
            weberString   = File.openAsString(weberSettingsPath);
            weberDefaults = split(weberString, "\n");
            // Safety: if file is shorter than expected, fall back to hard-coded defaults
            if (weberDefaults.length < 3) {
                weberDefaults = newArray("5", "3", "1");
            }
        } else {
            // First time use: define some sensible defaults
            weberDefaults = newArray("5", "3", "1"); // iterations, radius, falloff
        }

        Dialog.create("RNL Ranked Filter (Weber) Settings - Colour Maps");
            Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
            Dialog.addMessage("RNL Ranked Filter (Weber) settings for Colour Maps");
            Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
            Dialog.addNumber("Iterations:", parseFloat(weberDefaults[0]));
            Dialog.addNumber("Radius (pixels):", parseFloat(weberDefaults[1]));
            Dialog.addNumber("Falloff:", parseFloat(weberDefaults[2]));
            Dialog.addMessage("These settings control the RNL ranked filter that is applied after acuity correction.\n" +
                              "For Colour Maps we generally recommend modest values to avoid over-smoothing.");
        Dialog.show();

        iterations = Dialog.getNumber();
        radius     = Dialog.getNumber();
        falloff    = Dialog.getNumber();

        // Save WRF settings for the framework and later recall
        dataFile = File.open(weberSettingsPath);
            print(dataFile, iterations);
            print(dataFile, radius);
            print(dataFile, falloff);
        File.close(dataFile);

        print("- - - - - - - - - - - - - - - - - - - - -");
        print("QCPA Sub-Module - WRF (RNL Ranked Filter) Options (Colour Maps):");
        print("Iterations: " + iterations);
        print("Radius: " + radius);
        print("Falloff: " + falloff);
        print("");
    }
    // * * * END QCPA Sub-Module - WRF Settings
	
	// * * * START QCPA Sub-Module - Accuity Menu Options
	
	if (acCorChoice=="Gaussian" || acCorChoice=="AcuityView") {	
		settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPARNL.txt";
		if(File.exists(settingsFilePath) == 1){
			settingsString=File.openAsString(settingsFilePath);	// open txt data file
			defaultSettings=split(settingsString, "\n");
		}
																			
		//acChoice = newArray("Minimum resolvable angle", "Cycles per degree");
		acChoice = newArray("Cycles per degree");
		//calcChoice = newArray("Angular width of image", "Viewing distance");
		calcChoice = newArray("Viewing distance");
		
		Dialog.create("Acuity correction");
			Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
			Dialog.addMessage("QCPA acuity correction (Colour Maps)");
			Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
			Dialog.addMessage("_________________________________________Acuity Settings_________________________________________");
			Dialog.addChoice("Acuity units:", acChoice, defaultSettings[0]);
			Dialog.addNumber("Acuity value", defaultSettings[1]);
			Dialog.addMessage("____________________________________Distance/Angle Settings____________________________________");
			Dialog.addChoice("Method:", calcChoice, defaultSettings[2]);
			Dialog.addMessage("If using 'Viewing distance' the image must contain a scale-bar, and the units entered above\nmust match the scale bar units (e.g. mm). All angles are in degrees");
			Dialog.addNumber("Rescale to px per MRA", defaultSettings[4]);
			Dialog.addMessage("Automatically re-scale the image to a set number of pixels per MRA, 0=off. A value of 5 is recommended to avoid loosing more than 2% of spatial information");
			Dialog.addMessage("________________________________________Background Info________________________________________");
			Dialog.addMessage("AcuityView in QCPA is based on a 2016 Matlab script by S. Johnsen. Both, Gaussian & AcuityView remove spatial information that isn't available to a given visual system.\nHowever, a host of other/additional processing steps may go into truly approximating what an animal perceives.");
			
		Dialog.show();
		
	
		acUnits = Dialog.getChoice();
		acValue = Dialog.getNumber();
		acMethod = Dialog.getChoice();
		acDistance = distance;
		acRescale = Dialog.getNumber();		
						
		// * * * Writing settings 2 - QCPA Batch-AcuitySettings_subModule.txt
		settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPARNL.txt";
		dataFile = File.open(settingsFilePath);
			print(dataFile, acUnits);
			print(dataFile, acValue);
			print(dataFile, acMethod);
			print(dataFile, distance);
			print(dataFile, acRescale);
		File.close(dataFile);
		
		print("- - - - - - - - - - - - - - - - - - - - -");
		print("QCPA Sub-Module - Acuity View Options:");
		print("Acuity Units: "+acUnits);
		print("Acuity Value: "+acValue);
		print("Acuity Method: "+acMethod);
		print("Viewing Distances: "+distList);
		print("Rescale to MRA: "+acRescale);
		print("");
		// * * * END QCPA - Acuity Sub-module Settings
	}
	

	Dialog.create("Batch RNL Colour Maps Settings");
		Dialog.addMessage("The Batch QCPA Framework will use your custom defined Weber Fractions.");
		Dialog.addNumber("Resolution (px per JND):", 4);
		Dialog.show();

	RNLColourMapResolution = Dialog.getNumber();
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("RNL Colour Map Resolution = "+RNLColourMapResolution);
	print("");
} // End RNL ColourMap Settings



//End Module Settings	

Dialog.create("Cone Model Option");
	Dialog.addChoice("Cone Model #1", coneList);
	Dialog.addChoice("Cone Model #2", Array.concat("none",coneList));
	Dialog.addChoice("Cone Model #3", Array.concat("none",coneList));
	Dialog.addChoice("Cone Model #4", Array.concat("none",coneList));
	Dialog.addChoice("Cone Model #5", Array.concat("none",coneList));
Dialog.show();

coneModelChoice1 = Dialog.getChoice();
		if(endsWith(coneModelChoice1, ".class")){coneModelChoiceSanitised1 = replace(coneModelChoice1,".class","");}
		if(endsWith(coneModelChoice1, ".CLASS")){coneModelChoiceSanitised1 = replace(coneModelChoice1,".CLASS","");}
		if(endsWith(coneModelChoice1, ".java")){coneModelChoiceSanitised1 = replace(coneModelChoice1,".java","");}
		coneModelChoiceSanitised1= replace(coneModelChoiceSanitised1, "_", " ");

coneModelChoice2 = Dialog.getChoice();
		if(endsWith(coneModelChoice2, ".class")){coneModelChoiceSanitised2 = replace(coneModelChoice2,".class","");}
		if(endsWith(coneModelChoice2, ".CLASS")){coneModelChoiceSanitised2 = replace(coneModelChoice2,".CLASS","");}
		if(endsWith(coneModelChoice2, ".java")){coneModelChoiceSanitised2 = replace(coneModelChoice2,".java","");}
		coneModelChoiceSanitised2= replace(coneModelChoiceSanitised2, "_", " ");

coneModelChoice3 = Dialog.getChoice();
		if(endsWith(coneModelChoice3, ".class")){coneModelChoiceSanitised3 = replace(coneModelChoice3,".class","");}
		if(endsWith(coneModelChoice3, ".CLASS")){coneModelChoiceSanitised3 = replace(coneModelChoice3,".CLASS","");}
		if(endsWith(coneModelChoice3, ".java")){coneModelChoiceSanitised3 = replace(coneModelChoice3,".java","");}
		coneModelChoiceSanitised3= replace(coneModelChoiceSanitised3, "_", " ");

coneModelChoice4 = Dialog.getChoice();
		if(endsWith(coneModelChoice4, ".class")){coneModelChoiceSanitised4 = replace(coneModelChoice4,".class","");}
		if(endsWith(coneModelChoice4, ".CLASS")){coneModelChoiceSanitised4 = replace(coneModelChoice4,".CLASS","");}
		if(endsWith(coneModelChoice4, ".java")){coneModelChoiceSanitised4 = replace(coneModelChoice4,".java","");}
		coneModelChoiceSanitised4= replace(coneModelChoiceSanitised4, "_", " ");

coneModelChoice5 = Dialog.getChoice();
		if(endsWith(coneModelChoice5, ".class")){coneModelChoiceSanitised5 = replace(coneModelChoice5,".class","");}
		if(endsWith(coneModelChoice5, ".CLASS")){coneModelChoiceSanitised5 = replace(coneModelChoice5,".CLASS","");}
		if(endsWith(coneModelChoice5, ".java")){coneModelChoiceSanitised5 = replace(coneModelChoice5,".java","");}
		coneModelChoiceSanitised5= replace(coneModelChoiceSanitised5, "_", " ");

print("- - - - - - - - - - - - - - - - - - - - -");
print("Cone Model Choice 1 = "+coneModelChoiceSanitised1);
print("Cone Model Choice 2 = "+coneModelChoiceSanitised2);
print("Cone Model Choice 3 = "+coneModelChoiceSanitised3);
print("Cone Model Choice 4 = "+coneModelChoiceSanitised4);
print("Cone Model Choice 5 = "+coneModelChoiceSanitised5);

print("");print("");

getDateAndTime(year, month, week, day, hour, min, sec, msec);
print("Script Run Date: "+day+"/"+(month+1)+"/"+year+"  Time: " +hour+":"+min+":"+sec);
print("");
print("End of User Input Data");

//saves log
selectWindow("Log");
saveAs("Text", parentPath+"Batch_QCPA_Log.txt");

starttime = getTime();

for (y=0; y<speciesList.length; y++){
	roiManager("reset");
	currentSpecies = speciesList[y];
	print("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
		print("Current Working Species = "+currentSpecies);
	print("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
	DirIndividualslvl = parentPath+speciesList[y];
	IndividualsList = getFileList(DirIndividualslvl);
	print("There is/are "+IndividualsList.length+" individuals found in "+currentSpecies+" folder");
	print("");

	for(x=0; x<IndividualsList.length; x++){
		print("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ");
		currentIndividual = IndividualsList[x];
		list = getFileList(parentPath+speciesList[y]+currentIndividual+fs);
		print("list loc = "+parentPath+speciesList[y]+currentIndividual);
 		stop = false;
 			for (i=0; i<list.length && stop == false; i++) {
       			if (endsWith(list[i], ext)){
           			filename=list[i];	
           			}
			}
		 	for (i=0; i<list.length && stop == false; i++) {
				if (endsWith(list[i], ".mspec")){
           			mspecname=list[i];	
           			}
			}

			for (i=0; i<list.length && stop == false; i++) {
				if (endsWith(list[i], ".zip")){
           			zipname=list[i];
           			stop = true;
           			}
			}

		roiManager("reset");
		
		//Opening file
		print("Working on Individual "+x+1+" of "+IndividualsList.length+" in the directory called "+IndividualsList[x]);
		print("Image Filename = "+filename);

		opener = parentPath+speciesList[y]+IndividualsList[x]+filename;
		run("Load Multispectral Image", "select=["+parentPath+speciesList[y]+IndividualsList[x]+mspecname+"] image=[Linear Normalised Reflectance Stack]");
		windowtitle = getTitle();
		// */ opening file

		if(rotationMode==1){
			//Reading and applying image rotation
			rotation = File.openAsRawString(parentPath+speciesList[y]+fs+IndividualsList[x]+"rotation.txt");
			selectWindow(windowtitle);
			run("Rotate... ", "angle="+rotation+" grid=1 interpolation=Bilinear enlarge stack");
			print("Rotation applied to this image = "+rotation);
			// */ roation
			// */ Rotation
		}

		//Reading in ROIs
		roiManager("Open", parentPath+speciesList[y]+fs+IndividualsList[x]+zipname);
		roiManager("sort");


		//Reading applying coneModel choice
		coneModelnum = File.openAsRawString(parentPath+speciesList[y]+fs+IndividualsList[x]+"cone model.txt");
		if (coneModelnum ==1){currentConeModel = coneModelChoiceSanitised1;}
		if (coneModelnum ==2){currentConeModel = coneModelChoiceSanitised2;}
		if (coneModelnum ==3){currentConeModel = coneModelChoiceSanitised3;}
		if (coneModelnum ==4){currentConeModel = coneModelChoiceSanitised4;}
		if (coneModelnum ==5){currentConeModel = coneModelChoiceSanitised5;}
		
		print("For this image cone model number used =" + coneModelnum+" - "+currentConeModel);
		if(chrlimIgnore || lumlimIgnore == 1){run("Convert to Cone Catch", "model=["+currentConeModel+"] desaturate desaturation=0.000 remove replace=0.000");}
		if(chrlimIgnore || lumlimIgnore == 0)run("Convert to Cone Catch", "model=["+currentConeModel+"] desaturate desaturation=["+chrlim+"] remove replace=["+lumlim+"]");
		// */ ConeModel

		//Selects and creates a backup conecatch image window		
		windowtitle = getTitle();
		rename(filename);
		
		selectWindow(filename);

		
		for (k = 0; k<splitList.length; k++){
			listlength = splitList.length;	
			selectWindow(filename);
			roiManager("reset");
			roiManager("Open", parentPath+speciesList[y]+fs+IndividualsList[x]+zipname);
			roiManager("sort");


			if(moduleQCPA==1){
			// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
			//	Module A - QCPA
			// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
				
				if (moduleAnimalROI==1){
				// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
				//	Iteration A1 - Animal ROI selection
				// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
						
					// * * * ROI and distance settings
														//Sorted ROI list makes "Animal" the first ROI"
					distance = parseFloat(splitList[k]);  						//viewing distance in mm 
					roiSel = 0; 
					roiManager("select", roiSel);
					CurrentROIname = Roi.getName;
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, CurrentROIname);
								print(dataFile, roiSel);
								print(dataFile, 0);
							File.close(dataFile);

		
					// * * * Output directory creation
					outputDir = parentPath+speciesList[y]+fs+IndividualsList[x]+(distance/10)+"cm";
					File.makeDirectory(outputDir);
		
					// * * * Generation of common ROI name and placement at Position[0] in ROI list
					roiManager("select", roiSel);
					roiName = Roi.getName;
					roiManager("add");
					roiManager("select",roiManager("count")-1);
					roiManager("rename", "AA_CurrentROI");
					nROIs = roiManager("count");
					print("Chosen ROI ="+roiName);
					roiManager("sort");
			
					//QCPA - Load user defined settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					runWRF = defaultSettings[1];
					
					//Injects User defined settings into framework settings file
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
						print(dataFile, defaultSettings[3]);
						print(dataFile, defaultSettings[4]);
						print(dataFile, defaultSettings[5]);
						print(dataFile, "0");
					File.close(dataFile);
					clChoice = defaultSettings[2];					
					
					//Loads User defined Acuity Settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					//Injects user defined settings into framework settings file
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
						print(dataFile, distance);
						print(dataFile, defaultSettings[4]);
					File.close(dataFile);
					acValue = defaultSettings[1];
					//Loads user defined WRF Settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					//Injects user defined settings into the framework settings file
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-wrfSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
					File.close(dataFile);
					
					//Clustering
					if (clChoice == "RNL Cluster"){
						//Loads user defined Clustering settings
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLcluster-QCPA.txt";
						settingsString=File.openAsString(settingsFilePath);	// open txt data file
						defaultSettings=split(settingsString, "\n");	
						
						//Injects user defined settings into framework file
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLclusterSettings.txt";
						dataFile = File.open(settingsFilePath);	
							print(dataFile, defaultSettings[0]); 	//colJND
							print(dataFile, defaultSettings[1]); 	//lumJND
							print(dataFile, defaultSettings[2]); 	//loops
							print(dataFile, defaultSettings[3]);	//rMultiplier
							print(dataFile, defaultSettings[4]);	//minSize
							print(dataFile, defaultSettings[5]);	//compareFrom
							print(dataFile, defaultSettings[6]);	//stopN
							print(dataFile, defaultSettings[7]);	//recordFrom
							print(dataFile, defaultSettings[8]); 	//imLabel
							print(dataFile, defaultSettings[10]);	//hvOutput
							print(dataFile, defaultSettings[11]);	//mOutput
						File.close(dataFile);
					}
						
					runMacro(frameworkTool);
					
					selectWindow("Individual Particle Results");
						saveAs("Results", outputDir+fs+roiName+"_Individual Particle Results.csv");
						run("Close");
					selectWindow("Cluster Particle Analysis Summary Results");
						saveAs("Results", outputDir+fs+roiName+"_Cluster Particle Analysis Summary Results.csv");
						run("Close");
					selectWindow("Summary Results");
						saveAs("Results", outputDir+fs+roiName+"_Summary Results.csv");
						run("Close");
					selectWindow("ROI Cluster Results");
						saveAs("Results", outputDir+fs+roiName+"_ROI Cluster Results.csv");
						run("Close");
					selectWindow("Cluster Results");
						saveAs("Results", outputDir+fs+roiName+"_Cluster Results.csv");
						run("Close");
					if(runWRF ==1){
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Cluster_IDs");
						saveAs("Tiff", outputDir+fs+roiName+"_Zonemap.tif");
						close();
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Clustered");
						saveAs("Tiff", outputDir+fs+roiName+"_Clustered.tif");
						close();}		
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff);
						saveAs("Tiff", outputDir+fs+roiName+"_Blurred.tif");				
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0");
						close();
					print("");
	
					
					selectWindow(roiName+"_Blurred.tif");
					close();
	
					selectWindow("Log");
					saveAs("Text", outputDir+fs+roiName+"_Log.txt");
					print("\\Clear");
		
					while (isOpen("Exception")){selectWindow("Exception");run("Close");}
				}
		
				
		
				if (moduleBackgroundROI==1){
					// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
					//	Iteration A2 - Background ROI selection
					// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
					
					//Reconfiguring Windows (creates another copy of the cone catch image + reloads/sorts ROIs
					selectWindow(filename);
					close("\\Others");
					roiManager("reset");
					roiManager("Open", parentPath+speciesList[y]+fs+IndividualsList[x]+zipname);
					roiManager("sort");
					
					// * * * ROI and distance settings
					
					distance = parseFloat(splitList[k]);  //viewing distance in mm 
					roiSel = 2;							//Sorted ROI list places "Background' third in the ROI list
					roiManager("select", roiSel);
					CurrentROIname = Roi.getName;
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, CurrentROIname);
								print(dataFile, roiSel);
								print(dataFile, 0);
							File.close(dataFile);

					
					// * * * Generation of common ROI name and placement at Position[0] in ROI list
					roiManager("select", roiSel);
					roiName = Roi.getName;
					roiManager("add");
					roiManager("select",roiManager("count")-1);
					roiManager("rename", "AA_CurrentROI");
					nROIs = roiManager("count");
					print("Chosen ROI ="+roiName);
					roiManager("sort");
			
					//QCPA - Load user defined settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					runWRF = defaultSettings[1];
					
					//Injects User defined settings into framework settings file
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
						print(dataFile, defaultSettings[3]);
						print(dataFile, defaultSettings[4]);
						print(dataFile, defaultSettings[5]);
						print(dataFile, "0");
					File.close(dataFile);
				
	clChoice = defaultSettings[2];	
					
					//Loads User defined Acuity Settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					//Injects user defined settings into framework settings file
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
						print(dataFile, distance);
						print(dataFile, defaultSettings[4]);
					File.close(dataFile);
					
					//Loads user defined WRL Settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					//Injects user defined settings into the framework settings file
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-wrfSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
					File.close(dataFile);
					
					//Clustering
					if (clChoice == "RNL Cluster"){
						//Loads user defined Clustering settings
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLcluster-QCPA.txt";
						settingsString=File.openAsString(settingsFilePath);	// open txt data file
						defaultSettings=split(settingsString, "\n");	
						
						//Injects user defined settings into framework file
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLclusterSettings.txt";
						dataFile = File.open(settingsFilePath);	
							print(dataFile, defaultSettings[0]); 	//colJND
							print(dataFile, defaultSettings[1]); 	//lumJND
							print(dataFile, defaultSettings[2]); 	//loops
							print(dataFile, defaultSettings[3]);	//rMultiplier
							print(dataFile, defaultSettings[4]);	//minSize
							print(dataFile, defaultSettings[5]);	//compareFrom
							print(dataFile, defaultSettings[6]);	//stopN
							print(dataFile, defaultSettings[7]);	//recordFrom
							print(dataFile, defaultSettings[8]); 	//imLabel
							print(dataFile, defaultSettings[10]);	//hvOutput
							print(dataFile, defaultSettings[11]);	//mOutput
						File.close(dataFile);
					}
					
					runMacro(frameworkTool);
			
					//Saving Outputs into distance output folder
					selectWindow("Individual Particle Results");
						saveAs("Results", outputDir+fs+roiName+"_Individual Particle Results.csv");
						run("Close");
					selectWindow("Cluster Particle Analysis Summary Results");
						saveAs("Results", outputDir+fs+roiName+"_Cluster Particle Analysis Summary Results.csv");
						run("Close");
					selectWindow("Summary Results");
						saveAs("Results", outputDir+fs+roiName+"_Summary Results.csv");
						run("Close");
					selectWindow("ROI Cluster Results");
						saveAs("Results", outputDir+fs+roiName+"_ROI Cluster Results.csv");
						run("Close");
					selectWindow("Cluster Results");
						saveAs("Results", outputDir+fs+roiName+"_Cluster Results.csv");
						run("Close");
					if(runWRF==1){
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Cluster_IDs");
						saveAs("Tiff", outputDir+fs+roiName+"_Zonemap.tif");
						close();
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Clustered");}
						saveAs("Tiff", outputDir+fs+roiName+"_Clustered.tif");
						close();		
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff);
						saveAs("Tiff", outputDir+fs+roiName+"_Blurred.tif");				
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0");
						close();
					print("");
					
					selectWindow(roiName+"_Blurred.tif");
					close();
			
					selectWindow("Log");
					saveAs("Text", outputDir+fs+roiName+"_Log.txt");
					print("\\Clear");
			
					while (isOpen("Exception")){selectWindow("Exception");run("Close");}
	
				}
				
				if (moduleAnimalplusBackground==1){
					// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
					//	Iteration A3 - Animal + Background ROI selection
					// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
				
					//Reconfiguring Windows (creates another copy of the cone catch image + reloads/sorts ROIs
					selectWindow(filename);
					close("\\Others");
					roiManager("reset");
					roiManager("Open", parentPath+speciesList[y]+fs+IndividualsList[x]+zipname);
					roiManager("sort");
					
					// * * * ROI and distance settings
					
					distance = parseFloat(splitList[k]);  //viewing distance in mm 
					roiSel = 1;							//Sorted ROI list places "Background' third in the ROI list
					roiManager("select", roiSel);
					CurrentROIname = Roi.getName;
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, CurrentROIname);
								print(dataFile, roiSel);
								print(dataFile, 0);
							File.close(dataFile);

					
					// * * * Generation of common ROI name and placement at Position[0] in ROI list
					roiManager("select", roiSel);
					roiName = Roi.getName;
					roiManager("add");
					roiManager("select",roiManager("count")-1);
					roiManager("rename", "AA_CurrentROI");
					nROIs = roiManager("count");
					print("Chosen ROI ="+roiName);
					roiManager("sort");
			
			
					//QCPA - Load user defined settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					runWRF = defaultSettings[1];
					
					//Injects User defined settings into framework settings file
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
						print(dataFile, defaultSettings[3]);
						print(dataFile, defaultSettings[4]);
						print(dataFile, defaultSettings[5]);
						print(dataFile, "0");
					File.close(dataFile);
				
	clChoice = defaultSettings[2];	
				
					//Loads User defined Acuity Settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					//Injects user defined settings into framework settings file
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
						print(dataFile, distance);
						print(dataFile, defaultSettings[4]);
					File.close(dataFile);
					
					//Loads user defined WRL Settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					//Injects user defined settings into the framework settings file
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-wrfSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
					File.close(dataFile);
					
					//Clustering
					if (clChoice == "RNL Cluster"){
						//Loads user defined Clustering settings
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLcluster-QCPA.txt";
						settingsString=File.openAsString(settingsFilePath);	// open txt data file
						defaultSettings=split(settingsString, "\n");	
						
						//Injects user defined settings into framework file
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLclusterSettings.txt";
						dataFile = File.open(settingsFilePath);	
							print(dataFile, defaultSettings[0]); 	//colJND
							print(dataFile, defaultSettings[1]); 	//lumJND
							print(dataFile, defaultSettings[2]); 	//loops
							print(dataFile, defaultSettings[3]);	//rMultiplier
							print(dataFile, defaultSettings[4]);	//minSize
							print(dataFile, defaultSettings[5]);	//compareFrom
							print(dataFile, defaultSettings[6]);	//stopN
							print(dataFile, defaultSettings[7]);	//recordFrom
							print(dataFile, defaultSettings[8]); 	//imLabel
							print(dataFile, defaultSettings[10]);	//hvOutput
							print(dataFile, defaultSettings[11]);	//mOutput
						File.close(dataFile);
					}
					
					runMacro(frameworkTool);
			
					//Saving Outputs into distance output folder
					selectWindow("Individual Particle Results");
						saveAs("Results", outputDir+fs+roiName+"_Individual Particle Results.csv");
						run("Close");
					selectWindow("Cluster Particle Analysis Summary Results");
						saveAs("Results", outputDir+fs+roiName+"_Cluster Particle Analysis Summary Results.csv");
						run("Close");
					selectWindow("Summary Results");
						saveAs("Results", outputDir+fs+roiName+"_Summary Results.csv");
						run("Close");
					selectWindow("ROI Cluster Results");
						saveAs("Results", outputDir+fs+roiName+"_ROI Cluster Results.csv");
						run("Close");
					selectWindow("Cluster Results");
						saveAs("Results", outputDir+fs+roiName+"_Cluster Results.csv");
						run("Close");
					if(runWRF==1){
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Cluster_IDs");
						saveAs("Tiff", outputDir+fs+roiName+"_Zonemap.tif");
						close();
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Clustered");}
						saveAs("Tiff", outputDir+fs+roiName+"_Clustered.tif");
						close();		
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff);
						saveAs("Tiff", outputDir+fs+roiName+"_Blurred.tif");				
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0");
						close();
					print("");
					selectWindow(roiName+"_Blurred.tif");
					close();
			
					selectWindow("Log");
					saveAs("Text", outputDir+fs+roiName+"_Log.txt");
					print("\\Clear");
			
			
					while (isOpen("Exception")){selectWindow("Exception");run("Close");}
		
				} //end Module Animal + Background
			} //end module QCPA Only
			
			if (moduleLEIA==1){
			// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
			//	Module B - LEIA
			// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
				
				if (moduleAnimalROI==1){
				// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
				//	Iteration B1 - Animal ROI selection
				// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
				
					//Reconfiguring Windows (creates another copy of the cone catch image + reloads/sorts ROIs
					selectWindow(filename);
					close("\\Others");
					roiManager("reset");
					roiManager("Open", parentPath+speciesList[y]+fs+IndividualsList[x]+zipname);
					roiManager("sort");		
													
					// * * * ROI and distance settings
					roiSel = 0; 									//Sorted ROI list makes "Animal" the first ROI"
					distance = parseFloat(splitList[k]);  						//viewing distance in mm 
					roiManager("select", roiSel);
					CurrentROIname = Roi.getName;
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, CurrentROIname);
								print(dataFile, roiSel);
								print(dataFile, 0);
							File.close(dataFile);

					
					// * * * Output directory creation
					outputDir = parentPath+speciesList[y]+fs+IndividualsList[x]+(distance/10)+"cm";
					File.makeDirectory(outputDir);
		
					// * * * Generation of common ROI name and placement at Position[0] in ROI list
					roiManager("select", roiSel);
					roiName = Roi.getName;
					roiManager("add");
					roiManager("select",roiManager("count")-1);
					roiManager("rename", "AA_CurrentROI");
					nROIs = roiManager("count");
					print("Chosen ROI ="+roiName);
					roiManager("sort");
		
					//QCPA - Load user defined settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPALEIA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, "1");
						print(dataFile, "None");
						print(dataFile, defaultSettings[3]);
						print(dataFile, defaultSettings[4]);
						print(dataFile, "0");
						print(dataFile, "1");		//note LEIA turned on
					File.close(dataFile);
				
					//Acuity Settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPALEIA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
						print(dataFile, distance);
						print(dataFile, defaultSettings[4]);
					File.close(dataFile);
					
					//WRL Settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPALEIA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-wrfSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
					File.close(dataFile);
					
					//Load LEIA settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-leiaSettings-LEIA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-leiaSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, filename);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
						print(dataFile, defaultSettings[3]);
						print(dataFile, defaultSettings[4]);
						print(dataFile, defaultSettings[5]);
						print(dataFile, maxDisplay);
					File.close(dataFile);		

				runMacro(frameworkTool);
		
				
				//LEIA Output Directory naming and creation within the distance directory
				LEIADir = outputDir+fs+"LEIA";
				File.makeDirectory(LEIADir);
				LEIAoutputDir = LEIADir + fs + roiName;
				File.makeDirectory(LEIAoutputDir);		
			
				selectWindow("Local Edge Intensity Analysis");
					saveAs("Results", LEIAoutputDir+fs+"_Local Edge Intensity Analysis.csv");
					run("Close");
				selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Col_LEIA");
					saveAs("Tiff", LEIAoutputDir+fs+(distance/10)+"cm_Col_LEIA.tif");
					close();
				selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Lum_LEIA");
					saveAs("Tiff", LEIAoutputDir+fs+(distance/10)+"cm_Lum_LEIA.tif");
					close();

				//selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Cluster_IDs");
				//	close();
				//selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Clustered");
				//	close();		
				//selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff);
				//	close();
				selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0");
				rename(roiName+"_Blurred.tif");
				//	close();
				print("");
				selectWindow(roiName+"_Blurred.tif");
					close();
	
				selectWindow("Log");
				saveAs("Text", outputDir+fs+roiName+"LEIA_Log.txt");
				print("\\Clear");
		
				while (isOpen("Exception")){selectWindow("Exception");run("Close");}
	
				}
		
				// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
				//	Iteration B2 - Background ROI selection
				// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
		
				if (moduleBackgroundROI==1){
			
					//Reconfiguring Windows (creates another copy of the cone catch image + reloads/sorts ROIs
					selectWindow(filename);
					close("\\Others");
					roiManager("reset");
					roiManager("Open", parentPath+speciesList[y]+fs+IndividualsList[x]+zipname);
					roiManager("sort");
					
						
					// * * * ROI and distance settings
					roiSel = 2;							//Sorted ROI list places "Background' third in the ROI list
					distance = parseFloat(splitList[k]);  //viewing distance in mm 
					roiManager("select", roiSel);
					CurrentROIname = Roi.getName;
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, CurrentROIname);
								print(dataFile, roiSel);
								print(dataFile, 0);
							File.close(dataFile);

					
					// * * * Generation of common ROI name and placement at Position[0] in ROI list
					roiManager("select", roiSel);
					roiName = Roi.getName;
					roiManager("add");
					roiManager("select",roiManager("count")-1);
					roiManager("rename", "AA_CurrentROI");
					nROIs = roiManager("count");
					print("Chosen ROI ="+roiName);
					roiManager("sort");
			
			
					//QCPA - Load user defined settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPALEIA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, "1");
						print(dataFile, "None");
						print(dataFile, defaultSettings[3]);
						print(dataFile, defaultSettings[4]);
						print(dataFile, "0");
						print(dataFile, "1");		//note LEIA turned on
					File.close(dataFile);
				
					//Acuity Settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPALEIA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
						print(dataFile, distance);
						print(dataFile, defaultSettings[4]);
					File.close(dataFile);
					
					//WRL Settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPALEIA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-wrfSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
					File.close(dataFile);
					
					//Load LEIA settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-leiaSettings.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-leiaSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, filename);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
						print(dataFile, defaultSettings[3]);
						print(dataFile, defaultSettings[4]);
						print(dataFile, defaultSettings[5]);
						print(dataFile, maxDisplay);
					File.close(dataFile);		
	
					runMacro(frameworkTool);
		
					//LEIA Output Directory naming and creation within the distance directory
					LEIADir = outputDir+fs+"LEIA";
					File.makeDirectory(LEIADir);
					LEIAoutputDir = LEIADir + fs + roiName;
					File.makeDirectory(LEIAoutputDir);		
				
					selectWindow("Local Edge Intensity Analysis");
						saveAs("Results", LEIAoutputDir+fs+"_Local Edge Intensity Analysis.csv");
						run("Close");
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Col_LEIA");
						saveAs("Tiff", LEIAoutputDir+fs+(distance/10)+"cm_Col_LEIA.tif");
						close();
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Lum_LEIA");
						saveAs("Tiff", LEIAoutputDir+fs+(distance/10)+"cm_Lum_LEIA.tif");
						close();
	
					//selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Cluster_IDs");
						//	close();
					//selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Clustered");
						//	close();		
					//selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff);
						//	close();
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0");
						rename(roiName+"_Blurred.tif");
						//	close();
					print("");
					selectWindow(roiName+"_Blurred.tif");
					close();
		
					selectWindow("Log");
					saveAs("Text", outputDir+fs+roiName+"LEIA_Log.txt");
					print("\\Clear");
					
					while (isOpen("Exception")){selectWindow("Exception");run("Close");}
	
				}
				
				// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
				//	Iteration B3 - Animal + Background ROI selection
				// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
		
				if (moduleAnimalplusBackground==1){
		
					//Reconfiguring Windows (creates another copy of the cone catch image + reloads/sorts ROIs
					selectWindow(filename);
					close("\\Others");
					roiManager("reset");
					roiManager("Open", parentPath+speciesList[y]+fs+IndividualsList[x]+zipname);
					roiManager("sort");
					
					// * * * ROI and distance settings
					roiSel = 1;							//Sorted ROI list places "Background' third in the ROI list
					distance = parseFloat(splitList[k]);  //viewing distance in mm 
					roiManager("select", roiSel);
					CurrentROIname = Roi.getName;
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, CurrentROIname);
								print(dataFile, roiSel);
								print(dataFile, 0);
							File.close(dataFile);

					
					// * * * Generation of common ROI name and placement at Position[0] in ROI list
					roiManager("select", roiSel);
					roiName = Roi.getName;
					roiManager("add");
					roiManager("select",roiManager("count")-1);
					roiManager("rename", "AA_CurrentROI");
					nROIs = roiManager("count");
					print("Chosen ROI ="+roiName);
					roiManager("sort");
			
					//QCPA - Load user defined settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPALEIA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, "1");
						print(dataFile, "None");
						print(dataFile, defaultSettings[3]);
						print(dataFile, defaultSettings[4]);
						print(dataFile, "0");
						print(dataFile, "1");		//note LEIA turned on
					File.close(dataFile);
				
					//Acuity Settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPALEIA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
						print(dataFile, distance);
						print(dataFile, defaultSettings[4]);
					File.close(dataFile);
					
					//WRL Settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPALEIA.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-wrfSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, defaultSettings[0]);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
					File.close(dataFile);
					
					//Load LEIA settings
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-leiaSettings.txt";
					settingsString=File.openAsString(settingsFilePath);	// open txt data file
					defaultSettings=split(settingsString, "\n");
					
					settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-leiaSettings.txt";
					dataFile = File.open(settingsFilePath);
						print(dataFile, filename);
						print(dataFile, defaultSettings[1]);
						print(dataFile, defaultSettings[2]);
						print(dataFile, defaultSettings[3]);
						print(dataFile, defaultSettings[4]);
						print(dataFile, defaultSettings[5]);
						print(dataFile, maxDisplay);
					File.close(dataFile);		
	
					runMacro(frameworkTool);
			
					//LEIA Output Directory naming and creation within the distance directory
					LEIADir = outputDir+fs+"LEIA";
					File.makeDirectory(LEIADir);
					LEIAoutputDir = LEIADir + fs + roiName;
					File.makeDirectory(LEIAoutputDir);		
				
					selectWindow("Local Edge Intensity Analysis");
						saveAs("Results", LEIAoutputDir+fs+"_Local Edge Intensity Analysis.csv");
						run("Close");
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Col_LEIA");
						saveAs("Tiff", LEIAoutputDir+fs+(distance/10)+"cm_Col_LEIA.tif");
						close();
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Lum_LEIA");
						saveAs("Tiff", LEIAoutputDir+fs+(distance/10)+"cm_Lum_LEIA.tif");
						close();
	
					//selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Cluster_IDs");
						//	close();
					//selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Clustered");
						//	close();		
					//selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff);
						//	close();
					selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0");
						rename(roiName+"_Blurred.tif");
						//	close();
					print("");
					selectWindow(roiName+"_Blurred.tif");
						close();
					selectWindow("Log");
					saveAs("Text", outputDir+fs+roiName+"LEIA_Log.txt");
					print("\\Clear");		
			
					while (isOpen("Exception")){selectWindow("Exception");run("Close");}
	
				} //end Module Animal + Background
			} //end module LEIA
						
			if (moduleGABRAT==1){					
			// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
			//	Module C - GabRat
			// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
			
					
				//Reconfiguring Windows (creates another copy of the cone catch image + reloads/sorts ROIs
				selectWindow(filename);
				close("\\Others");
				roiManager("reset");
				roiManager("Open", parentPath+speciesList[y]+fs+IndividualsList[x]+zipname);
				roiManager("sort");
				
				run("Select All");
				roiManager("Add");
				roiManager("Select",roiManager("count")-1);
				roiManager("Rename", "whole image");
				

				// * * * ROI and distance settings
				roiSel = roiManager("count")-1; 									//Sorted ROI list makes "Animal" the first ROI"
				roiManager("select", roiSel);
				CurrentROIname = Roi.getName;
			
				distance = parseFloat(splitList[k]);  						//viewing distance in mm 
				
				settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";
				dataFile = File.open(settingsFilePath);
					print(dataFile, CurrentROIname);
					print(dataFile, roiSel);
					print(dataFile, 1);
				File.close(dataFile);
			
				// * * * Output directory creation
				outputDir = parentPath+speciesList[y]+fs+IndividualsList[x]+(distance/10)+"cm";
				File.makeDirectory(outputDir);
	
			
	
				//QCPA - Load user defined settings
				settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPAGabRat.txt";
				settingsString=File.openAsString(settingsFilePath);	// open txt data file
				defaultSettings=split(settingsString, "\n");
				
				//Injects User defined settings into framework settings file
				settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings.txt";
				dataFile = File.open(settingsFilePath);
					print(dataFile, defaultSettings[0]);
					print(dataFile, defaultSettings[1]);
					print(dataFile, defaultSettings[2]);
					print(dataFile, defaultSettings[3]);
					print(dataFile, defaultSettings[4]);
					print(dataFile, defaultSettings[5]);
					print(dataFile, "0");		//note LEIA turned off
				File.close(dataFile);
		
				//Loads User defined Acuity Settings
				settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPAGabrat.txt";
				settingsString=File.openAsString(settingsFilePath);	// open txt data file
				defaultSettings=split(settingsString, "\n");
				
				//Injects user defined settings into framework settings file
				settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings.txt";
				dataFile = File.open(settingsFilePath);
					print(dataFile, defaultSettings[0]);
					print(dataFile, defaultSettings[1]);
					print(dataFile, defaultSettings[2]);
					print(dataFile, distance);
					print(dataFile, defaultSettings[4]);
				File.close(dataFile);
				acValue = defaultSettings[1];
				//Loads user defined WRF Settings
				settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPAGabrat.txt";
				settingsString=File.openAsString(settingsFilePath);	// open txt data file
				defaultSettings=split(settingsString, "\n");
				
				//Injects user defined settings into the framework settings file
				settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-wrfSettings.txt";
				dataFile = File.open(settingsFilePath);
					print(dataFile, defaultSettings[0]);
					print(dataFile, defaultSettings[1]);
					print(dataFile, defaultSettings[2]);
				File.close(dataFile);
				
				//Loads user defined GabRat Settings
				settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-GABRAT_ROI-disruption_GabRat_subModule.txt";
				settingsString=File.openAsString(settingsFilePath);	// open txt data file
				defaultSettings=split(settingsString, "\n");
				
				
				//Injects user defined settings into the framework QCPA settings file
				settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-GABRAT_ROI-disruption.txt";
				dataFile = File.open(settingsFilePath);
					print(dataFile, defaultSettings[0]);
					print(dataFile, defaultSettings[1]);
					print(dataFile, defaultSettings[2]);
					print(dataFile, defaultSettings[3]);
				File.close(dataFile);
												
				runMacro(frameworkTool);

				roiManager("select", roiSel);
				roiManager("delete");
				runMacro(batchGabrat);
				
				GabRatDir = outputDir+fs+"GabRat";
				File.makeDirectory(GabRatDir);
	
				selectWindow("Results");
					saveAs("Results", GabRatDir+fs+"_GabRat_Results.csv");
					run("Close");
		
				//selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Cluster_IDs");
				//		close();
				//	selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff+"_Clustered");
				//		close();		
				//	selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff);
				//		close();
					
		
					selectWindow("Log");
					saveAs("Text", outputDir+fs+CurrentROIname+"GabRat_Log.txt");
					print("\\Clear");
				
					while (isOpen("Exception")){selectWindow("Exception");run("Close");}
		
				settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";
				dataFile = File.open(settingsFilePath);
					print(dataFile, CurrentROIname);
					print(dataFile, roiSel);
					print(dataFile, 0);
				File.close(dataFile);

				
				
					}//End GabRat
		
					if (moduleRNLColourMap ==1){					
					// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
					//	Module D - RNL Colour Maps
					// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
			
						if (moduleAnimalROI ==1){	
						// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
						//	Iteration D1 - Animal 
						// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
			
							//Reconfiguring Windows (creates another copy of the cone catch image + reloads/sorts ROIs
							selectWindow(filename);
							close("\\Others");
							roiManager("reset");
							roiManager("Open", parentPath+speciesList[y]+fs+IndividualsList[x]+zipname);
							roiManager("sort");
							
							// * * * ROI and distance settings
							roiSel = 0; 									//Sorted ROI list makes "Animal" the first ROI"
							distance = parseFloat(splitList[k]);  						//viewing distance in mm 
							roiManager("select", roiSel);
							CurrentROIname = Roi.getName;
						settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, CurrentROIname);
								print(dataFile, roiSel);
								print(dataFile, 0);
							File.close(dataFile);

								
							// * * * Output directory creation
							outputDir = parentPath+speciesList[y]+fs+IndividualsList[x]+(distance/10)+"cm";
							File.makeDirectory(outputDir);
				
							// * * * Generation of common ROI name and placement at Position[0] in ROI list
							roiManager("select", roiSel);
							roiName = Roi.getName;
							roiManager("add");
							roiManager("select",roiManager("count")-1);
							roiManager("rename", "AA_CurrentROI");
							nROIs = roiManager("count");
							print("Chosen ROI ="+roiName);
							roiManager("sort");
				
							//QCPA - Load user defined settings
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPARNL.txt";
							settingsString=File.openAsString(settingsFilePath);	// open txt data file
							defaultSettings=split(settingsString, "\n");
							
							//Injects User defined settings into framework settings file
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, defaultSettings[0]);
								print(dataFile, defaultSettings[1]);
								print(dataFile, "None");
								print(dataFile, defaultSettings[3]);
								print(dataFile, defaultSettings[4]);
								print(dataFile, "0");
								print(dataFile, "0");		//note LEIA turned off
							File.close(dataFile);
					
							//Loads User defined Acuity Settings
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPARNL.txt";
							settingsString=File.openAsString(settingsFilePath);	// open txt data file
							defaultSettings=split(settingsString, "\n");
							
							//Injects user defined settings into framework settings file
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, defaultSettings[0]);
								print(dataFile, defaultSettings[1]);
								print(dataFile, defaultSettings[2]);
								print(dataFile, distance);
								print(dataFile, defaultSettings[4]);
							File.close(dataFile);
							acValue = defaultSettings[1];
																		
							runMacro(frameworkTool);

							if (runWRF == 1) {
    							// Framework has produced the WRF'ed acuity image:
    							// filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff
    							selectWindow(
       							filename+"_Acuity"+acValue+"_Dist"+distance+"_0_WeberFiltered_itr"
       							+ iterations+"_rad"+radius+"_fall"+falloff
    							);
							} else {
   							// No WRF → use the acuity-only image
    							selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0");
							}

							
							
							saveAs("Tiff", outputDir+fs+roiName+"_Blurred.tif");
			
							if (runWRF == 1) {
    							selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0");
   							close();

							selectWindow(roiName+"_Blurred.tif");

							if (moduleRNLColourMap==1){
								RNL_dir = outputDir+fs+"Colour_Maps";
									File.makeDirectory(RNL_dir);
								RNLoutputDir = RNL_dir + fs + roiName;
									File.makeDirectory(RNLoutputDir);
								run("1 Create RNL Colour Maps From ROIs", "visual=[CustomWeberFraction] resolution="+RNLColourMapResolution+" select=["+RNLoutputDir+fs+"]");
							}
			
							selectWindow(filename);
								close("\\Others");
							
							selectWindow("Log");
							saveAs("Text", outputDir+fs+roiName+"RNLColourMaps_Log.txt");
							print("\\Clear");
						}//End Animal (D1)
						
						if (moduleBackgroundROI ==1){	
						// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
						//	Iteration D2 - Background 
						// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
			
							//Reconfiguring Windows (creates another copy of the cone catch image + reloads/sorts ROIs)
							selectWindow(filename);
							close("\\Others");
							roiManager("reset");
							roiManager("Open", parentPath+speciesList[y]+fs+IndividualsList[x]+zipname);
							roiManager("sort");
							
							// * * * ROI and distance settings
							roiSel = 2; 									//Sorted ROI list makes "Background" the first ROI"
							distance = parseFloat(splitList[k]);  						//viewing distance in mm 
							roiManager("select", roiSel);
							CurrentROIname = Roi.getName;
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, CurrentROIname);
								print(dataFile, roiSel);
								print(dataFile, 0);
							File.close(dataFile);
						
							// * * * Output directory creation
							outputDir = parentPath+speciesList[y]+fs+IndividualsList[x]+(distance/10)+"cm";
							File.makeDirectory(outputDir);
				
							// * * * Generation of common ROI name and placement at Position[0] in ROI list
							roiManager("select", roiSel);
							roiName = Roi.getName;
							roiManager("add");
							roiManager("select",roiManager("count")-1);
							roiManager("rename", "AA_CurrentROI");
							nROIs = roiManager("count");
							print("Chosen ROI ="+roiName);
							roiManager("sort");
				
							//QCPA - Load user defined settings
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPARNL.txt";
							settingsString=File.openAsString(settingsFilePath);	// open txt data file
							defaultSettings=split(settingsString, "\n");
							
							//Injects User defined settings into framework settings file
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, defaultSettings[0]);
								print(dataFile, defaultSettings[1]);
								print(dataFile, "None");
								print(dataFile, defaultSettings[3]);
								print(dataFile, defaultSettings[4]);
								print(dataFile, "0");
								print(dataFile, "0");		//note LEIA turned off
							File.close(dataFile);
					
							//Loads User defined Acuity Settings
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPARNL.txt";
							settingsString=File.openAsString(settingsFilePath);	// open txt data file
							defaultSettings=split(settingsString, "\n");
							
							//Injects user defined settings into framework settings file
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, defaultSettings[0]);
								print(dataFile, defaultSettings[1]);
								print(dataFile, defaultSettings[2]);
								print(dataFile, distance);
								print(dataFile, defaultSettings[4]);
							File.close(dataFile);
							acValue = defaultSettings[1];
																		
							runMacro(frameworkTool);
							
							
							if (runWRF == 1) {
    								// Use the WRF-filtered acuity image
   								selectWindow(
       									filename+"_Acuity"+acValue+"_Dist"+distance+
        								"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff
    								);
							} else {
    								// Use the acuity-only image
    								selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0");
							}

							// Save the chosen image as the per-ROI blurred image
							saveAs("Tiff", outputDir+fs+roiName+"_Blurred.tif");		
							
							selectWindow(roiName+"_Blurred.tif");
							if (moduleRNLColourMap==1){
								RNL_dir = outputDir+fs+"Colour_Maps";
									File.makeDirectory(RNL_dir);
								RNLoutputDir = RNL_dir + fs + roiName;
									File.makeDirectory(RNLoutputDir);		
								run("1 Create RNL Colour Maps From ROIs", "visual=[CustomWeberFraction] resolution="+RNLColourMapResolution+" select=["+RNLoutputDir+fs+"]");
							}
			
							selectWindow(filename);
								close("\\Others");
							
							selectWindow("Log");
							saveAs("Text", outputDir+fs+roiName+"RNLColourMaps_Log.txt");
							print("\\Clear");
						}//End Background (D2)

						if (moduleAnimalplusBackground ==1){	
						// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
						//	Iteration D3 - Animal + Background 
						// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
			
							//Reconfiguring Windows (creates another copy of the cone catch image + reloads/sorts ROIs
							selectWindow(filename);
							close("\\Others");
							roiManager("reset");
							roiManager("Open", parentPath+speciesList[y]+fs+IndividualsList[x]+zipname);
							roiManager("sort");
							
							// * * * ROI and distance settings
							roiSel = 1; 									//Sorted ROI list makes "Animal+ Background" the first ROI"
							distance = parseFloat(splitList[k]);  						//viewing distance in mm 
							roiManager("select", roiSel);
							CurrentROIname = Roi.getName;
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, CurrentROIname);
								print(dataFile, roiSel);
								print(dataFile, 0);
							File.close(dataFile);

						
							// * * * Output directory creation
							outputDir = parentPath+speciesList[y]+fs+IndividualsList[x]+(distance/10)+"cm";
							File.makeDirectory(outputDir);
				
							// * * * Generation of common ROI name and placement at Position[0] in ROI list
							roiManager("select", roiSel);
							roiName = Roi.getName;
							roiManager("add");
							roiManager("select",roiManager("count")-1);
							roiManager("rename", "AA_CurrentROI");
							nROIs = roiManager("count");
							print("Chosen ROI ="+roiName);
							roiManager("sort");
				
							//QCPA - Load user defined settings
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPARNL.txt";
							settingsString=File.openAsString(settingsFilePath);	// open txt data file
							defaultSettings=split(settingsString, "\n");
							
							//Injects User defined settings into framework settings file
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, defaultSettings[0]);
								print(dataFile, defaultSettings[1]);
								print(dataFile, "None");
								print(dataFile, defaultSettings[3]);
								print(dataFile, defaultSettings[4]);
								print(dataFile, "0");
								print(dataFile, "0");		//note LEIA turned off
							File.close(dataFile);
					
							//Loads User defined Acuity Settings
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPARNL.txt";
							settingsString=File.openAsString(settingsFilePath);	// open txt data file
							defaultSettings=split(settingsString, "\n");
							
							//Injects user defined settings into framework settings file
							settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings.txt";
							dataFile = File.open(settingsFilePath);
								print(dataFile, defaultSettings[0]);
								print(dataFile, defaultSettings[1]);
								print(dataFile, defaultSettings[2]);
								print(dataFile, distance);
								print(dataFile, defaultSettings[4]);
							File.close(dataFile);
							acValue = defaultSettings[1];
																		
							runMacro(frameworkTool);
							
							if (runWRF == 1) {
    								// Use the WRF-filtered acuity image
   								selectWindow(
       									filename+"_Acuity"+acValue+"_Dist"+distance+
        								"_0_WeberFiltered_itr"+iterations+"_rad"+radius+"_fall"+falloff
    								);
							} else {
    								// Use the acuity-only image
    								selectWindow(filename+"_Acuity"+acValue+"_Dist"+distance+"_0");
							}

							// Save the chosen image as the per-ROI blurred image
							saveAs("Tiff", outputDir+fs+roiName+"_Blurred.tif");			
							
							selectWindow(roiName+"_Blurred.tif");
							if (moduleRNLColourMap==1){
								RNL_dir = outputDir+fs+"Colour_Maps";
									File.makeDirectory(RNL_dir);
								RNLoutputDir = RNL_dir + fs + roiName;
									File.makeDirectory(RNLoutputDir);		
								run("1 Create RNL Colour Maps From ROIs", "visual=[CustomWeberFraction] resolution="+RNLColourMapResolution+" select=["+RNLoutputDir+fs+"]");
							}
			
							selectWindow(filename);
								close("\\Others");
							
							selectWindow("Log");
							saveAs("Text", outputDir+fs+roiName+"RNLColourMaps_Log.txt");
							print("\\Clear");
						}//End Animal + Background (D3)						
					}//End RNL Colour Maps
			
				

			} //End Individual Distances	
		} while(nImages>0){close();} 
		//End Individual Animals (from same species)
	}//End Species List

endtime = (getTime()-starttime)/60000;


//exit message to notify user that the script has finished.
title = "Batch Completed";
msg = "Put down that coffee! Your analysis is finished and took "+endtime+" min";
waitForUser(title, msg);


