scripttitle="Batch QCPA - About";
version="1.0";
date="20/10/2022";
description="A heavily customised batch processing script for analyses in the Quantitative Colour Pattern Analysis (QCPA) framework with integrated functionality for GabRat - Cite XY when using this script"
    showMessage("Batch QCPA - About", "<html>" 
    +"<h1><font color=black>ImageJ Script Macro: "+scripttitle+"</h1> "
    +"<p1>Version: "+version+" ("+date+")</p1>"
    +"<H2><font size=3>Created by Cedric van den Berg & Nicholas Condon</H2>"	
    +"<p1><font size=2> contact: c.vandenberg@uq.edu.au / n.condon@uq.edu.au \n </p1>" 
    +"<P4><font size=2> Available for use/modification/sharing under the "+"<p4><a href=https://opensource.org/licenses/MIT/>MIT License</a><\h4> </P4>"
    +"<h3>   <\h3>"    
    +"<p1><font size=3 \b i>"+description+"</p1>"
   	+"<h1><font size=2> </h1>"  
	+"<h0><font size=5> </h0>"
    +"");