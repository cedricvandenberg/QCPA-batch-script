moduleLEIA=1;

if (moduleLEIA==1){
	// * * * START LEIA Module -  QCPA Framework Settings
	
	showMessage("Batch QCPA With LEIA - About", "<html>" 
    +"<h1><font size=8 color=black>QCPA Settings Section</h1> "
    +"<H2><font size=4>The following menus and user input settings relate to the running of the QCPA with LEIA Module</H2>"
    +"<br>"	
    +"<p1><font size=3> More information about QCPA and LEIA can be found <a href=https://www.empiricalimaging.com/questions/categories/qcpa/>here</a></p1>" 
    +"<br>"
    +"<P1><font size=3> Dont forget to cite the publication. <a href=https://besjournals.onlinelibrary.wiley.com/doi/full/10.1111/2041-210X.13328>here</a></P1>"
     +"<br>"
      +"<p2>This module requires settings for the following:</p2>"
      +"<li>QCPA Settings</li>"
      +"<li>Acuity View Settings</li>"
      +"<li>RNL Filtering Settings</li>"
      +"<li>LEIA Specific Settings</li>"
     +"");
	
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPALEIA.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	}
	
	acuityMethod = newArray("None", "AcuityView", "Gaussian");
	//clusterMethod = newArray("None", "RNL Cluster", "Naive Bayes");
	clusterMethod = newArray("RNL Cluster", "None");
							
	Dialog.create("QCPA sub-Module - QCPA Framework Options");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("QCPA SETTINGS");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("Select which aspects of processing to apply:");
		Dialog.addChoice("Acuity Correction", acuityMethod, defaultSettings[0]);
		Dialog.addMessage("AcuityView (modified for QCPA) is fast and uses FFT, but requires use on whole-images.\nThe Gaussian method is slower, but can measure ROIs independently\nof their surroundings");
		Dialog.addCheckbox("RNL_Ranked_Filter", defaultSettings[1]);
		Dialog.addChoice("Clustering", clusterMethod, defaultSettings[2]);
		if (moduleLEIA==1){Dialog.addMessage("If using LEIA mode, its not recommended to run clustering.\n If LEIA is run in combination with other modules, clustering will be deactivated.");}
		if (moduleGABRAT==1){Dialog.addMessage("Note: if using GabRat it is not recommended to run filtering or clustering. If GabRat is run with other modules, these will be deactivated.");}
		if(moduleRNLColourMap==1){Dialog.addMessage("RNL Filtering and clustering will affect the output of the Colour maps. We recommend only applying RNL filtering");}
		//Dialog.addNumber("Luminance Weber fraction", defaultSettings[4]); // this can come from the custom weber menu
		Dialog.addMessage("When using the QCPA framework cite: \nvan den Berg & Troscianko et al. (2020) Quantitative Colour Pattern Analysis (QCPA):A Comprehensive Framework for the Analysis of Colour Patterns in Nature, \nMethods in Ecology and Evolution, 11, 316-332 (2020)");
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/running-the-qcpa-framework/");
	Dialog.show();

	acCorChoice = Dialog.getChoice();
	runWRF = Dialog.getCheckbox();
	clChoice = Dialog.getChoice();
	vsChoice = 		"CustomWeberFraction";
	//lumWeber = Dialog.getNumber();
	plAnalysis = 1;

	// * * * Writing settings 1 - QCPA Batch-Frameworksettings_QCPA-subModule.txt
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-frameworkSettings-QCPALEIA.txt";
	dataFile = File.open(settingsFilePath);
		print(dataFile, acCorChoice);
		print(dataFile, runWRF);
		print(dataFile, clChoice);
		print(dataFile, vsChoice);
		print(dataFile, lumWeber);
		print(dataFile, plAnalysis);
		print(dataFile, "0");
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("QCPA Framework Options: ");
	print("Acuity Correction Method: "+acCorChoice);
	print("RNL Ranked Filter: "+runWRF);
	print("Clustering method: "+clChoice);
	print("Luminance Weber fraction: "+lumWeber);
	print("Particle Analysis: "+plAnalysis);
	print("");	
	
	// * * * START QCPA Sub-Module - Accuity Menu Options
	if (acCorChoice=="Gaussian" || acCorChoice=="AcuityView") {	
		settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPALEIA.txt";
		if(File.exists(settingsFilePath) == 1){
			settingsString=File.openAsString(settingsFilePath);	// open txt data file
			defaultSettings=split(settingsString, "\n");
		}
																			
		//acChoice = newArray("Minimum resolvable angle", "Cycles per degree");
		acChoice = newArray("Cycles per degree");
		//calcChoice = newArray("Angular width of image", "Viewing distance");
		calcChoice = newArray("Viewing distance");
		
		Dialog.create("AcuityView for ImageJ");
			Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
			Dialog.addMessage("QCPA ACUITY PROCESSING FOR IMAGEJ");
			Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
			Dialog.addMessage("_________________________________________Acuity Settings_________________________________________");
			Dialog.addChoice("Acuity units:", acChoice, defaultSettings[0]);
			Dialog.addNumber("Acuity value", defaultSettings[1]);
			Dialog.addMessage("____________________________________Distance/Angle Settings____________________________________");
			Dialog.addChoice("Method:", calcChoice, defaultSettings[2]);
			Dialog.addMessage("If using 'Viewing distance' the image must contain a scale-bar, and the units entered above\nmust match the scale bar units (e.g. mm). All angles are in degrees");
			Dialog.addNumber("Rescale to px per MRA", defaultSettings[4]);
			Dialog.addMessage("Automatically re-scale the image to a set number of pixels per MRA, 0=off. A value of 5 is recommended to avoid loosing more than 2% of spatial information");
			Dialog.addMessage("________________________________________Background Info________________________________________");
			Dialog.addMessage("AcuityView in QCPA is based on a 2016 Matlab script by S. Johnsen. It removes spatial information that isn't available to a given visual system, but a host\nof other processing steps may go into changing what an animal actually perceives.");
			Dialog.addMessage("If you use AcuityView rather than Gaussian, please also consider citing:\nCaves, E. M. & Johnsen, S. AcuityView: An r package for portraying the effects of visual acuity on scenes observed by an animal. \nMethods in Ecology and Evolution 9, 793-797 (2018).");
			Dialog.addHelp("https://eleanorcaves.weebly.com/acuityview-software.html");
		Dialog.show();
	
		acUnits = Dialog.getChoice();
		acValue = Dialog.getNumber();
		acMethod = Dialog.getChoice();
		acDistance = distance;
		acRescale = Dialog.getNumber();		
						
		// * * * Writing settings 2 - QCPA Batch-AcuitySettings_subModule.txt
		settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings-QCPALEIA.txt";
		dataFile = File.open(settingsFilePath);
			print(dataFile, acUnits);
			print(dataFile, acValue);
			print(dataFile, acMethod);
			print(dataFile, distance);
			print(dataFile, acRescale);
		File.close(dataFile);
		
		print("- - - - - - - - - - - - - - - - - - - - -");
		print("QCPA Sub-Module - Acuity View Options:");
		print("Acuity Units: "+acUnits);
		print("Acuity Value: "+acValue);
		print("Acuity Method: "+acMethod);
		print("Viewing Distances: "+distList);
		print("Rescale to MRA: "+acRescale);
		print("");
		// * * * END QCPA - Acuity Sub-module Settings
	}
	
	// * * * START  WRF / RNL Ranked Filter Settings
	if (runWRF ==1){
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPALEIA.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	}

	Dialog.create("RNL Ranked Filter Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("RNL Ranked Filter Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addNumber("Iterations:", defaultSettings[0]);
		Dialog.addNumber("Radius:", defaultSettings[1]);
		Dialog.addMessage("If you specified a pixels-per-MRA, you should\nuse the same number as the radius here.");
		Dialog.addNumber("Falloff:", defaultSettings[2]);
		Dialog.addMessage("Higher falloff values create a steeper falloff\nin the influence of neighbouring pixels,\npreserving more fine detail");
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/rnl-ranked-filter/");	
	Dialog.show();
	
	iterations = parseInt(Dialog.getNumber());
	radius = parseInt(Dialog.getNumber());
	falloff = Dialog.getNumber();

	// * * *  Writing settings 3 - Batch_wrfSettings_SubModule.txt
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-WRFSettings-QCPALEIA.txt";
	dataFile = File.open(settingsFilePath);
		//print(dataFile, lumWeber);
		print(dataFile, iterations);
		print(dataFile, radius);
		print(dataFile, falloff);
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("RNL Ranked Filter Options: ");
	print("Iterations: "+iterations);
	print("Radius: "+radius);
	print("Falloff: "+falloff);
	print("");
	}//end WRF loop

if (clChoice == "RNL Cluster"){
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLcluster-LEIA.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	} 

	Dialog.create("RNL Clustering Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("RNL Clustering Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addNumber("Colour JND Threshold", defaultSettings[0]);
		Dialog.addNumber("Luminance JND Threshold", defaultSettings[1]);
		Dialog.addNumber("Loops", defaultSettings[2]);
		Dialog.addNumber("Radius multiplier", defaultSettings[3]);
		Dialog.addNumber("Minimum cluster size", defaultSettings[4]);
		Dialog.addNumber("Compare all clusters from pass:", defaultSettings[5]);
		Dialog.addNumber("Stop clustering if number of clusters is below", defaultSettings[6]);
		Dialog.addNumber("Record output from pass", defaultSettings[7]);
		//Dialog.addString("Image Label", "filename", defaultSettings[8]);
		//Dialog.addNumber("Luminance Weber fraction", defaultSettings[9]);
		Dialog.addCheckbox("Show separate horizontal and vertical adjacency results", defaultSettings[9]); 
		Dialog.addCheckbox("Output adjacency matrix", defaultSettings[10]); 
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/rnl-clustering/");	
	Dialog.show();

	colJND = Dialog.getNumber();
	lumJND = Dialog.getNumber();
	loops = parseInt(Dialog.getNumber());
	rMultiplier = Dialog.getNumber();
	minSize = parseInt(Dialog.getNumber());
	compareFrom = parseInt(Dialog.getNumber());
	stopN = parseInt(Dialog.getNumber());
	recordFrom = parseInt(Dialog.getNumber());
	imLabel = "filename";
	hvOutput = Dialog.getCheckbox();
	mOutput = Dialog.getCheckbox();

	// -----------------------SAVE PREVIOUSLY USED SETTINGS----------------------------
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-RNLcluster-LEIA.txt";
	dataFile = File.open(settingsFilePath);
		print(dataFile, colJND);
		print(dataFile, lumJND);
		print(dataFile, loops);
		print(dataFile, rMultiplier);
		print(dataFile, minSize);
		print(dataFile, compareFrom);
		print(dataFile, stopN);
		print(dataFile, recordFrom);
		print(dataFile, imLabel);
		print(dataFile, "X"); //printing 'junk' to ensure array stays same size
		print(dataFile, hvOutput);
		print(dataFile, mOutput);
	File.close(dataFile);
	
	print("- - - - - - - - - - - - - - - - - - - - -");
	print("RNL Clustering Options: ");
	print("ColourJND Threshold: "+colJND);
	print("Luminance JND Threshold: "+lumJND);
	print("Loops: "+loops);
	print("Radius Multiplier: "+rMultiplier);
	print("Minimum cluster size: "+minSize);
	print("Compare all clusters from pass: "+compareFrom);
	print("Stop clustering if number of clusters is below: "+stopN);
	print("Record output from pass: "+recordFrom);
	print("Show seperate horizontal + vertical adjacency results: "+hvOutput);
	print("Output adjacency matrix: "+mOutput);
	print("");
	
}//End RNL Clustering sub-Module


	//Start LEIA LEIA Settings
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-leiaSettings.txt";
	if(File.exists(settingsFilePath) == 1){
		settingsString=File.openAsString(settingsFilePath);	// open txt data file
		defaultSettings=split(settingsString, "\n");
	} 
	
	tOptions = newArray("none", "log", "sqrt");
	Dialog.create("Local Edge Intensity Analysis Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addMessage("LEIA Local Edge Intensity Analysis Settings");
		Dialog.addMessage("* * * * * * * * * * * * * * * * * * * * * * * * * * ");
		Dialog.addChoice("Transform delta S values:", tOptions, defaultSettings[2]);
		Dialog.addNumber("Ignnore_chromatic delta S values below:", defaultSettings[3]);
		Dialog.addNumber("Ignnore_luminance delta S values below:", defaultSettings[4]);
		Dialog.addCheckbox("Show horizontal and vertical data", defaultSettings[5]);
		Dialog.addNumber("Maximum display value", defaultSettings[6]);
		Dialog.addHelp("http://www.empiricalimaging.com/knowledge-base/local-edge-intensity-analysis-leia/");
	Dialog.show();

	imLabel = "filename";
	//lumWeber = "1";
	tChoice = Dialog.getChoice();
	ict = Dialog.getNumber();
	ilt = Dialog.getNumber();
	hvOutputLEIA = Dialog.getCheckbox();
	maxDisplay = Dialog.getNumber();

	// -----------------------SAVE PREVIOUSLY USED SETTINGS----------------------------
	settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-leiaSettings-LEIA.txt";
	dataFile = File.open(settingsFilePath);
		print(dataFile, imLabel);
		print(dataFile, lumWeber);
		print(dataFile, tChoice);
		print(dataFile, ict);
		print(dataFile, ilt);
		print(dataFile, hvOutputLEIA);
		print(dataFile, maxDisplay);
	File.close(dataFile);		

	print("- - - - - - - - - - - - - - - - - - - - -");
	print("LEIA Options: ");
	print("Transform delta S values: "+tChoice);
	print("Ignore chromatic delta S values below:"+ict);
	print("Ignore luminance delta S values below: "+ilt);
	print("Show seperate horizontal + vertical adjacency results: "+hvOutputLEIA);
	print("Maximum display value: "+maxDisplay);
	print("");
}

	// * * * END QCPA sub-Module - QCPA LEIA Framework settings

