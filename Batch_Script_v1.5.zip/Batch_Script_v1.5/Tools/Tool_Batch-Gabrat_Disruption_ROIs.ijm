run("Set Measurements...", "area mean min redirect=None decimal=9");
//setBatchMode(true);

settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-GABRAT_ROI-disruption.txt";


print(settingsFilePath);


if(File.exists(settingsFilePath) == 1){
			settingsString=File.openAsString(settingsFilePath);	// open txt data file
			defaultSettings=split(settingsString, "\n");
			}
	
angles = defaultSettings[0];
sigma = defaultSettings[1];
gamma = defaultSettings[2];
freq = defaultSettings[3];





for(j=0; j<roiManager("count"); j++){


roiManager("Select", j);

tStr = getInfo("selection.name");

if(startsWith(tStr, "Scale Bar") == false){ // only measure ROIs which aren't scale bars
tStr = getTitle + "_" + tStr;

	for(i=1; i<nSlices+1; i++){
		setSlice(i);
		tStr2 = tStr + "_" + getMetadata("Label");
		run("GabRat Disruption", "number_of_angles="+angles+" sigma="+sigma+" gamma="+gamma+" frequency="+freq+" label=&tStr2");
	}
}// scale bar
}//j roi





