/*
_______________________________________________________________________

	Title: Gaussian Acuity Control for Image
	Author: Jolyon Troscianko
	Date: 26/9/18
.................................................................................................................

Description:
''''''''''''''''''''''''''''''''
This tool is essentially an alternative to AcuityView, which uses a Gaussian pass filter instead
of FFT using a specific MTF. The Gaussian distribution fits the MTF pretty well, but the main
advantage is that this can easily be applied to ROIs of any shape and size. FFTs are a pig
to use with anything which isn't rectangular.

The sigma of the Gaussian blur has been specifically modelled against the pixels-per-MRA chosen,
specifically in the range from 4 px/MRA to 16 px/MRA. This testing ensured the blurring results in contrasts
which are 2% of the original. As such the safest range of px/MRAs to use is between 4 and 16.

This script requires a linear 32-bit image or image stack (ideally created with the micaToolbox).
If viewing distance is used to work out the angular width of the image, then the image must contain
a scale bar (as created through the mspec image generation workflow).

_________________________________________________________________________
*/
fs = File.separator;

batchToolsPath = getDirectory("plugins")+"micaToolbox"+fs+"Batch QCPA"+fs+"Tools"+fs;

batchImageRescaler = batchToolsPath+"Tool_Batch-Multispectral_Image_Scaler_No_Scale_Bar.ijm";




imTitle  = getTitle();
//setBatchMode(true);
getMinAndMax(oMin, oMax);

//run("Duplicate...", "duplicate");

oID = getImageID();

settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";

	settingsString=File.openAsString(settingsFilePath);	// open txt data file
	defaultSettings=split(settingsString, "\n");
	

	gabRatMode = defaultSettings[2];
	



w = getWidth();
h = getHeight();


if(w>h)
	D = w;
else D = h;

//-----------------------------LIST ROIs-----------------------

roiList = newArray("AA_CurrentROI");
roiFullList = newArray();
nROIs = roiManager("count");

for(j=0; j<nROIs; j++){
	roiManager("Select", j);
	tStr = getInfo("selection.name");
	roiFullList = Array.concat(roiFullList, tStr);
	if(startsWith(tStr, "Scale Bar") == false) // only measure ROIs which aren't scale bars
		roiList = Array.concat(roiList, tStr);
}

nROIs = roiManager("count");
for(j=0; j<nROIs; j++){
	roiManager("Select", j);
	tStr = getInfo("selection.name");
	if(startsWith(tStr, "whole")){
		roiSelection =j;
		gabRatMode = 1;}
}


//------------------LOAD PREVIOUSLY USED VALUES---------------------

settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings.txt";
if(File.exists(settingsFilePath) == 1){
	settingsString=File.openAsString(settingsFilePath);	// open txt data file
	defaultSettings=split(settingsString, "\n");
} 

//------------------USER OPTIONS---------------------

acChoice = newArray("Minimum resolvable angle", "Cycles per degree");
calcChoice = newArray("Angular width of image", "Viewing distance");

Dialog.create("Gaussian Acuity Control");

	Dialog.addMessage("_________________________________________Acuity Settings_________________________________________");
	Dialog.addChoice("Acuity units:", acChoice, defaultSettings[0]);
	Dialog.addNumber("Acuity value", defaultSettings[1]);

	Dialog.addMessage("____________________________________Distance/Angle Settings____________________________________");
	Dialog.addChoice("Method:", calcChoice, defaultSettings[2]);
	Dialog.addNumber("Distance or angle value", defaultSettings[3]);
	Dialog.addMessage("If using 'Viewing distance' the image must contain a scale-bar, and the units entered above\nmust match the scale bar units (e.g. mm). All angles are in degrees");

	Dialog.addNumber("Rescale to px per MRA", defaultSettings[4]);
	Dialog.addMessage("Automatically re-scale the image to a set number of pixels per MRA");

	Dialog.addMessage("______________________________________Specify ROI______________________________________");
	Dialog.addChoice("ROI:", roiList,  "CurrentROI");
	Dialog.addMessage("When using this Beta version of the framework cite: van den Berg &\nTroscianko et al. (2019) Quantitative Colour Pattern Analysis (QCPA):\nA Comprehensive Framework for the Analysis of Colour Patterns in\nNature, BIORXIV/2019/592261");
	
//Dialog.show();

aMethod = Dialog.getChoice();
aVal = Dialog.getNumber();
bMethod = Dialog.getChoice();
bVal = Dialog.getNumber();
pxMRA = Dialog.getNumber(); // pixels per minimum resolvable angle
if(pxMRA == 0)
	exit("Unlike AcuityView (which uses FFT) the modelling used here assumes the image has been\nscaled to a specified pixels-per-minimum-resolvable-angle, so you cannot set it to zero here");

settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-CurrentROI.txt";
settingsString=File.openAsString(settingsFilePath);	// open txt data file
defaultSettings=split(settingsString, "\n");	


currentROIname = defaultSettings[0];
roiChoice = 0;
roiSel = 0;
for(j=0; j<roiFullList.length; j++)
	if(roiChoice == "AA_CurrentROI"){
		roiSel = j;}

if(gabRatMode==1){
	roiChoice = "whole image";
	roiSel = defaultSettings[1];
}


// -----------------------SAVE PREVIOUSLY USED SETTINGS----------------------------
settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/Batch-acuitySettings.txt";
dataFile = File.open(settingsFilePath);
	print(dataFile, aMethod);
	print(dataFile, aVal);
	print(dataFile, bMethod);
	print(dataFile, bVal);
	print(dataFile, pxMRA);
File.close(dataFile);

//------------------CALCULATE VARIABLES---------------------

print("________________________________");
print("------Gaussian Acuity Control------");

if(aMethod == "Minimum resolvable angle"){
	MRA = aVal;
	imTitle = imTitle + "_MRA" + aVal;
} else{
	MRA = 1/aVal;
	imTitle = imTitle + "_Acuity" + aVal;
	print("Acuity = " + aVal);
}

if(bMethod == "Angular width of image"){
	alpha = bVal; // angular width of image
	imTitle = imTitle + "_AW" + bVal;
}else{ //--------------------------calculate angular width based on distance and image scale-----------------------
	imTitle = imTitle + "_Dist" + bVal;
	print("Distance = " + bVal);

// get scale bar px/mms

	nSelections = roiManager("count");

	scaleFlag = 0;

	for(j=0; j<nSelections; j++){
		roiManager("select", j);
		selName = getInfo("selection.name");

		if( startsWith(selName, "Scale") == 1){ // found the scale bar - extract the info
			scaleLoc = j;
			scaleFlag = scaleFlag+1;
			scaleInfo = split(selName, ":");
			pxMm = parseFloat(scaleInfo[1])/parseFloat(scaleInfo[2]);
			//pixLength = scaleInfo[1];
			//scaleMm = scaleInfo[2];
		}
		
	}

	if(scaleFlag == 0)
		exit("No scale bar found\n \nUse the 'Save ROIs' script to add\none by selecting it and pressing 'S',\nthen press '0' to save the ROIs");
	if(scaleFlag > 1)
		showMessageWithCancel("Multiple Scale Bars", "There's more than one scale bar\n \nThis script will only use the last one");

	imageWidth = D/pxMm;
	imageAngle = atan((imageWidth/2)/bVal)*2; // image angle in radians
	alpha = 180 * imageAngle/PI; // image angle in degrees
}


print("MRA = " + MRA);
if(w>h)
	print("Image angular width = " + alpha);
else 
	print("Image angular height = " + alpha);

print("Image Region = " + currentROIname);

print("________________________________");



//------------------Image Scaling-----------------

// scale to a given number of px per MRA

sR= (pxMRA*alpha/MRA)/D; // scaled angular width ratio

if(sR > 1)
	waitForUser("These settings will increase the image dimensions beyond their original size, which invalidates the smoothing");

if(roiChoice != "whole image"){
	roiManager("select", roiSel);
	srcSelectionType = selectionType();
	if(srcSelectionType == -1)
		exit("Batch Gaussian Acuity Control: no active source selection before Duplicate. Current ROI = " + currentROIname);
	
	run("Duplicate...", "duplicate");

	// ImageJ may create the cropped duplicate but leave no active selection on it.
	// First try to restore the previous selection. If the source ROI was rectangular,
	// selecting the whole duplicate is geometrically equivalent to the original crop.
	if(selectionType() == -1)
		run("Restore Selection");
	if(selectionType() == -1 && srcSelectionType == 0){
		run("Select All");
		print("Batch Gaussian Acuity Control: duplicate of rectangular ROI had no active selection; selected whole duplicate. Current ROI = " + currentROIname);
	}
	if(selectionType() == -1)
		exit("Batch Gaussian Acuity Control: selection was lost after Duplicate. Current ROI = " + currentROIname + "; source selection type = " + srcSelectionType);

	roiManager("Add");
	roiManager("deselect");
for(i=0; i<nROIs; i++){ // delete all other ROIs
		roiManager("select", 0);
		roiManager("delete");
	}
}




tStr = d2s(sR,12);

settingsFilePath = getDirectory("plugins") + "micaToolbox/Batch QCPA/Settings/tStr.txt";

dataFile = File.open(settingsFilePath);
	print(dataFile, tStr);
File.close(dataFile);

	runMacro(batchImageRescaler);


if(roiChoice != "whole image"){
	roiManager("select", 0); // select new ROI
	postResizeSelectionType = selectionType();

	// The batch rescaler can leave only a scale-bar line ROI in the ROI Manager.
	// Make Inverse requires an area ROI. Valid ImageJ area selections include
	// rectangles/ovals/polygons/freehand/traced ROIs and composite ROIs (type 9).
	// Recover safely only for rectangular source ROIs; otherwise preserve original behaviour.
	if(postResizeSelectionType == -1 || (postResizeSelectionType >= 5 && postResizeSelectionType <= 8) || postResizeSelectionType == 10){
		if(srcSelectionType == 0){
			// The image was already cropped to the rectangular source ROI before resizing;
			// therefore the correct post-resize analysis ROI is the whole resized image.
			cntROIs = roiManager("count");
			for(k=0; k<cntROIs; k++){
				roiManager("select", 0);
				roiManager("delete");
			}
			run("Select All");
			roiManager("Add");
			roiManager("Select", 0);
			roiManager("rename", roiChoice);
			print("Batch Gaussian Acuity Control: after resizing, no valid area ROI remained; selected whole resized rectangular crop. Current ROI = " + currentROIname);
		} else {
			exit("Batch Gaussian Acuity Control: after resizing, no valid area ROI remained for a non-rectangular ROI. Current ROI = " + currentROIname + "; source selection type = " + srcSelectionType + "; post-resize selection type = " + postResizeSelectionType);
		}
	} else {
		run("Make Inverse");
		run("Set...", "value=0 stack");
		run("Make Inverse");
		//----make inverse can select regions outside the image boundary, so the code here cleans up the ROI
		roiManager("Add");
		run("Select All");
		roiManager("Add");
		roiManager("Select", 1);
		roiManager("Select", newArray(1,2));
		roiManager("AND");
		roiManager("Add");

		roiManager("Select", newArray(0,1,2));
		roiManager("delete");

		roiManager("Select", 0);

		roiManager("rename", roiChoice);
	}

	//roiManager("select", 0); // select new ROI
}

roiManager("select", 0);

oID = getImageID();
D = round(D*sR);



//-----------Gaussian blur modelling based on testing:------------
M = 0.45045736;
C = -0.09008928;

sigma = M*pxMRA+C;
if(roiChoice == "whole image"){
	run("Gaussian Blur...", "sigma=&sigma stack");
	imTitle = imTitle + "_WholeImage";
	rename(imTitle);
} else {
	// Use the same ROI-normalised Gaussian implementation as the manual
	// QCPA framework. This is essential for numerical parity: a standard
	// full-image Gaussian followed by ROI copy/paste includes pixels outside
	// the analysis ROI and is not equivalent near ROI boundaries.
	tStr = "sigma="+sigma;

	selectImage(oID);
	roiManager("Select", 0);
	if(selectionType() == -1)
		exit("Batch Gaussian Acuity Control: no active ROI before ROI-normalised blur. Current ROI = " + currentROIname);

	for(i=1; i<=nSlices; i++){
		setSlice(i);
		// Re-select on every slice so the intended AA_CurrentROI is explicit.
		roiManager("Select", 0);
		if(selectionType() == -1)
			exit("Batch Gaussian Acuity Control: ROI was lost before Gaussian Blur ROI. Current ROI = " + currentROIname + "; slice = " + i);
		run("Gaussian Blur ROI", tStr);
	}

	setSlice(1);
	roiManager("Select", 0);
	imTitle = imTitle + "_" + roiChoice;
	rename(imTitle);
}

setMinAndMax(oMin, oMax);
setBatchMode("show");

