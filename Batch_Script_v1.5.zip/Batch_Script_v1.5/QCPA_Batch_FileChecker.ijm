print("\\Clear");
print("* * * * * * * * * * * * * * * * * * * *");
print("Batch QCPA Directory Checker");
print("* * * * * * * * * * * * * * * * * * * *");
ext = ".ORF";
fs = File.separator;

parentPath = getDirectory("Choose a Directory");
speciesList = getFileList(parentPath);
numSpecies = speciesList.length;
print("Working Directory Location: " + parentPath);
print("Number of species folders found = " + numSpecies);

starttime = getTime();
setOption("ExpandableArrays", true);
failcount = 0;

for (y = 0; y < speciesList.length; y++) {
    currentSpecies = speciesList[y];
    print("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
    print("Current Working Species = " + currentSpecies);
    print("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
    DirIndividualslvl = parentPath + speciesList[y];
    IndividualsList = getFileList(DirIndividualslvl);
    print("   There is/are " + IndividualsList.length + " individuals found in " + currentSpecies + " folder");
    print("");

    for (x = 0; x < IndividualsList.length; x++) {
        currentIndividual = IndividualsList[x];
        list = getFileList(parentPath + speciesList[y] + currentIndividual + fs);
        print("      Individual Directory = " + currentIndividual);
        checkOK = 1;

        // Check for each file type
        if (!containsFileWithExtension(list, ext)) {
            checkOK = 0;
            print("         Image File missing");
        }

        if (!containsFileWithExtension(list, "model.txt")) {
            checkOK = 0;
            print("         Cone Model File missing");
        }

        if (!containsFileWithExtension(list, ".zip")) {
            checkOK = 0;
            print("         RoiSet.Zip File missing");
        }

        if (File.exists(parentPath + speciesList[y] + currentIndividual + fs + ".mspec") == 1) {
            mspec = 1;
        } else {
            checkOK = 0;
            print("         .mspec File missing");
        }

        if (!containsFileWithExtension(list, "rotation.txt")) {
            checkOK = 0;
            print("         rotation.txt File missing");
        }

        if (checkOK == 1) {
            print("         Directory check PASSED");
        } else {
            print("         Directory check FAILED");
            failcount = failcount + 1;
        }
    }
}

print("");
print("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
print("Directory Check Completed");
if (failcount == 0) {
    print("   All directories Passed");
} else {
    print("   At least one Directory Failed");
}
print("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
// Function to check if the list contains a file with a specific extension
function containsFileWithExtension(fileList, extension) {
    for (i = 0; i < fileList.length; i++) {
        if (endsWith(fileList[i], extension)) {
            return true;
        }
    }
    return false;
}